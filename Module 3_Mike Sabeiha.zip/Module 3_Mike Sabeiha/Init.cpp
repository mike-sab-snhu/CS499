// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"
#include "Monkey.h"
#include "Dog.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds methods to initialize lists for both testing and validation
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Adds dogs to a list for testing
public static void initializeDogList() {
    Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "Intake", false, "United States");
    Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
    Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "In Service", true, "Canada");
    Dog dog4 = new Dog("Rocker", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "In Service", false, "United States");

    dogList.add(dog1);
    dogList.add(dog2);
    dogList.add(dog3);
    dogList.add(dog4);
}


// Adds monkeys to a list for testing
public static void initializeMonkeyList() {
    Monkey monkey1 = new Monkey("Laugher", "Capuchin", "male", "2", "25.6", "14.5", "9.1", "25.2", "05-12-2019", "United States", "Intake", false, "United States");
    Monkey monkey2 = new Monkey("Clapper", "Tamarin", "male", "3", "25.6", "14.5", "9.1", "25.2", "05-12-2019", "United States", "Phase I", false, "United States");
    Monkey monkey3 = new Monkey("Smeller", "Macaque", "female", "7", "25.6", "14.5", "9.1", "25.2", "05-12-2019", "United States", "In Service", false, "United States");
    Monkey monkey4 = new Monkey("Quacker", "Macaque", "female", "7", "25.6", "14.5", "9.1", "25.2", "05-12-2019", "United States", "In Service", false, "United States");

    monkeyList.add(monkey1);
    monkeyList.add(monkey2);
    monkeyList.add(monkey3);
    monkeyList.add(monkey4);
}


// Adds strings to lists for validation checks
public static void initializeAttributeLists() {

    // Adds training status types to training status list to validate user input
    listTrainingStatus = new String[]{
            "Intake", "Phase I", "Phase II", "Phase III", "Phase IV", "Phase V", "In Service", "Farm" };

    // Adds monkey species types to monkey species list to validate user input
    listMonkeySpecies = new String[]{ "Capuchin", "Guenon", "Macaque", "Marmoset", "Squirrel Monkey", "Tamarin" };

    // Adds dog breed types to dog breed list to validate user input
    listDogBreeds = new String[]{ "Unknown", "Mixed Breed", "Affenpinscher", "Afghan Hound", "Airedale Terrier",
    "Akita", "Alaskan Malamute", "American Staffordshire Terrier", "American Water Spaniel", "Australian Cattle Dog",
    "Australian Shepherd", "Australian Terrier", "Basenji", "Basset Hound", "Beagle", "Bearded Collie",
    "Bedlington Terrier", "Bernese Mountain Dog", "Bichon Frise", "Black And Tan Coonhound", "Bloodhound",
    "Border Collie", "Border Terrier", "Borzoi", "Boston Terrier", "Bouvier Des Flandres", "Boxer", "Briard",
    "Brittany", "Brussels Griffon", "Bull Terrier", "Bulldog", "Bullmastiff", "Cairn Terrier", "Canaan Dog",
    "Chesapeake Bay Retriever", "Chihuahua", "Chinese Crested", "Chinese Shar-Pei", "Chow Chow", "Clumber Spaniel",
    "Cocker Spaniel", "Collie", "Curly-Coated Retriever", "Dachshund", "Dalmatian", "Doberman Pinscher",
    "English Cocker Spaniel", "English Setter", "English Springer Spaniel", "English Toy Spaniel", "Eskimo Dog",
    "Finnish Spitz", "Flat-Coated Retriever", "Fox Terrier", "Foxhound", "French Bulldog", "German Shepherd",
    "German Shorthaired Pointer", "German Wirehaired Pointer", "Golden Retriever", "Gordon Setter", "Great Dane",
    "Greyhound", "Irish Setter", "Irish Water Spaniel", "Irish Wolfhound", "Jack Russell Terrier",
    "Japanese Spaniel", "Keeshond", "Kerry Blue Terrier", "Komondor", "Kuvasz", "Labrador Retriever",
    "Lakeland Terrier", "Lhasa Apso", "Maltese", "Manchester Terrier", "Mastiff", "Mexican Hairless",
    "Newfoundland", "Norwegian Elkhound", "Norwich Terrier", "Otterhound", "Papillon", "Pekingese", "Pointer",
    "Pomeranian", "Poodle", "Pug", "Puli", "Rhodesian Ridgeback", "Rottweiler", "Saint Bernard", "Saluki",
    "Samoyed", "Schipperke", "Schnauzer", "Scottish Deerhound", "Scottish Terrier", "Sealyham Terrier",
    "Shetland Sheepdog", "Shih Tzu", "Siberian Husky", "Silky Terrier", "Skye Terrier", "Staffordshire Bull Terrier",
    "Soft-Coated Wheaten Terrier", "Sussex Spaniel", "Spitz", "Tibetan Terrier", "Vizsla", "Weimaraner",
    "Welsh Terrier", "West Highland White Terrier", "Whippet", "Yorkshire Terrier", "Terrier", "Pit Bull" };

    // Adds country names to country name list to validate user input
    listCountryNames = new String[]{
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia",
    "Australia", "Austria", "Azerbaijan", "The Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium",
    "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria",
    "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad",
    "Chile", "China", "Colombia", "Comoros", "The Congo",  "Costa Rica", "The Ivory Coast", "Croatia", "Cuba",
    "Cyprus", "Czechia", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt",
    "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France",
    "Gabon", "The Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea",
    "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq",
    "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "North Korea",
    "South Korea", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya",
    "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta",
    "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia",
    "Montenegro", "Morocco", "Mozambique", "Myanmar", "Burma", "Namibia", "Nauru", "Nepal", "Netherlands",
    "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau",
    "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania",
    "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa",
    "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone",
    "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "Spain", "Sri Lanka",
    "Sudan", "South Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania",
    "Thailand", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda",
    "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu",
    "Vatican City", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe" };
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////