// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"

using namespace std;

class Monkey : public RescueAnimal {
private:
    // Instance variables
    std::string species;
    std::string height;
    std::string bodyLength;
    std::string tailLength;

public:
    // Constructor
    Monkey(std::string name, std::string species, std::string gender, std::string age,
        std::string height, std::string bodyLength, std::string tailLength,
        std::string weight, std::string acquisitionDate, std::string acquisitionCountry,
        std::string trainingStatus, bool reserved, std::string inServiceCountry) {

        // Using the setters inherited from RescueAnimal
        setName(name);
        setSpecies(species);
        setGender(gender);
        setAge(age);
        setHeight(height);
        setBodyLength(bodyLength);
        setTailLength(tailLength);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
    }

    // Accessors (Getters)
    std::string getSpecies() const { return species; }
    std::string getHeight() const { return height; }
    std::string getBodyLength() const { return bodyLength; }
    std::string getTailLength() const { return tailLength; }

    // Mutators (Setters)
    void setSpecies(const std::string& inpSpecies) { species = inpSpecies; }
    void setHeight(const std::string& inpHeight) { height = inpHeight; }
    void setBodyLength(const std::string& inpBodyLength) { bodyLength = inpBodyLength; }
    void setTailLength(const std::string& inpTailLength) { tailLength = inpTailLength; }
};