// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"
#include "Monkey.h"
#include "Dog.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds the Intake Methods that prompt the user, validate input, process, and return
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Method to receive, validate, process, and return user input on the dog's name
public static String receiveUserInput_DogName(Scanner scnr) {
    String tmpName = null; // local variable to store dog's name

    do { // loop to receive and validate user input on the dog's name
        System.out.println("\nWhat is the dog's name?"); // prompt user to input name

        try { // try loop to ensure user enters valid string
            String userInpDogName = scnr.nextLine(); // grab next line
            for (Dog dog : dogList) { // checking to see if the dog name is already in use on our list
                if (dog.getName().equalsIgnoreCase(userInpDogName)) { // if the dog name is in use
                    System.out.println("\nThis dog is already in our system."); // print feedback to user
                    System.out.println("You'll need to give them a unique name."); // print hint to user
                    System.out.println("Try adding a number to the end of their name."); // print hint to user
                }
                else { // if the dog name is not in use
                    tmpName = userInpDogName; // set the local variable to user input
                }
            }
        }

        catch (Exception e) { // if the user makes an invalid entry
            System.out.println("Your entry cannot be blank."); // print feedback to user
            System.out.println("Please enter the dog's name."); // print feedback to user
        }
    } while (tmpName == null); // repeat loop until a valid entry is stored

    return tmpName; // return the dog name as string
}


//  Method to receive, validate, process, and return user input on the monkey's name
public static String receiveUserInput_MonkeyName(Scanner scnr) {
    String tmpName = null; // local variable to store monkey's name

    do { // loop to receive and validate user input on the monkey's name
        System.out.println("\nWhat is the monkey's name?"); // prompt user to input name

        try { // try loop to ensure user enters valid string
            String userInpMonkeyName = scnr.nextLine(); // grab next line
            for (Monkey monkey : monkeyList) { // checking to see if the monkey name is already in use on our list
                if (monkey.getName().equalsIgnoreCase(userInpMonkeyName)) { // if monkey name is in use
                    System.out.println("\nThis monkey is already in our system."); // print feedback to user
                    System.out.println("You'll need to give them a unique name."); // print hint to user
                    System.out.println("Try adding a number to the end of their name."); // print hint to user
                }
                else { // if the monkey name is not in use
                    tmpName = userInpMonkeyName; // set the local variable to user input
                }
            }
        }

        catch (Exception e) { // if the user makes an invalid entry
            System.out.println("Your entry cannot be blank."); // print feedback to user
            System.out.println("Please enter the monkey's name."); // print feedback to user
        }
    } while (tmpName == null); // repeat loop until a valid entry is stored

    return tmpName; // return the monkey name as string
}


// Method to receive, validate, process, and return user input on the dog's breed
public static String receiveUserInput_DogBreed(Scanner scnr) {
    String tmpBreed = null; // local variable to store dog's breed

    do { // loop to receive and validate user input on the dog's breed
        System.out.println("\nWhat is the dog's breed?"); // prompt user for input
        System.out.println("\nYou can enter 'Mixed Breed' or 'Unknown' if necessary."); // print hint to user

        boolean matchFound = false; // loop breaker based on whether a match was found

        while (!matchFound) { // while there is not yet a match found
            String userInpDogBreed = scnr.nextLine(); // grab the next line of user input
            for (String breed : listDogBreeds) { // search the list of dog breeds
                if (breed.equalsIgnoreCase(userInpDogBreed)) { // if the user input matches a breed in the database
                    tmpBreed = breed; // set the local variable to that breed from database (better formatting)
                    matchFound = true; // set loop breaker to true
                }
            }

            if (!matchFound) { // if no match was found and loop breaker is still false
                System.out.println("\nPlease enter the dog's breed."); // prompt user for input
                System.out.println("Be sure to use the correct spelling."); // print hint to user
            }
        } // this while loop repeats until a match is found

    } while (tmpBreed == null); // this do-while repeats until a valid breed bas been store to local variable

    return tmpBreed; // returns dog breed as string
}


// Method to receive, validate, process, and return user input on the monkey's species
public static String receiveUserInput_MonkeySpecies(Scanner scnr) {
    String tmpSpecies = null; // local variable to store monkey species

    do { // loop to receive and validate user input on the Monkey's species
        System.out.println("\nWe'll need to know the monkey's species."); // inform user about next steps
        System.out.println("\nWe can only accept the following:"); // print hint to user
        System.out.println("Capuchin, Guenon, Macaque, Marmoset, Squirrel Monkey, or Tamarin."); // print options
        System.out.println("\nIs your monkey's species on this list?"); // prompt user for yes/no input

        String userInpMonkeyCheck = scnr.nextLine(); // grab next line from user input and store as local variable

        // if the user input is neither 'yes' nor 'no'...
        if (!(userInpMonkeyCheck.equalsIgnoreCase("yes") || userInpMonkeyCheck.equalsIgnoreCase("no"))) {
            System.out.println("\nPlease enter 'yes' or 'no'."); // prompt user for input
        }
        else { // if the user input is either 'yes' or 'no'...

            // if the user's monkey species is on the list...
            if (userInpMonkeyCheck.equalsIgnoreCase("yes")) {
                System.out.println("\nWhat is the Monkey's Species?"); // prompt user for input

                boolean matchFound = false; // loop breaker that toggles when match is found

                while (!matchFound) { // while a match has yet to be found
                    String userInpMonkeySpecies = scnr.nextLine(); // grab user input and store as local variable
                    for (String species : listMonkeySpecies) { // search list of monkey species
                        if (species.equalsIgnoreCase(userInpMonkeySpecies)) { // if user input matches a species
                            tmpSpecies = species; // set the temporary variable to the species
                            matchFound = true; // toggle loop breaker to exit loop
                        }
                    }

                    if (!matchFound) { // if no match was found, prompt the user with the following
                        System.out.println("\nPlease enter the monkey's species as any of the following:");
                        System.out.println("Capuchin, Guenon, Macaque, Marmoset, Squirrel Monkey, or Tamarin.");
                    }
                }
            }

            else { // if the user's monkey species is not on the list
                System.out.println("\nWe cannot accept your monkey."); // print feedback to user
                System.out.println("\nYou'll be returned to the main menu now."); // print feedback to user
                break; // break to menu
            }
        }
    } while (tmpSpecies == null); // this loop will continue until a valid special is stored

    return tmpSpecies; // return the monkey species as string
}


// Method to receive, validate, process, and return user input on the animal's gender
public static String receiveUserInput_Gender(Scanner scnr, String inpAnimalType) {
    String tmpGender = null; // local variable to store animal gender

    do { // loop to receive and validate user input on the animal's gender
        System.out.println("\nWhat is the " + inpAnimalType + "'s gender?"); // prompt user for input
        String userInpGender = scnr.nextLine(); // grab user input and store as local variable

        // if the user input is either 'male' or 'female'...
        if (userInpGender.equalsIgnoreCase("male") || userInpGender.equalsIgnoreCase("female")) {
            tmpGender = userInpGender; // set the local variable to user input
        }
        else { // if the user input is neither 'male' nor 'female', print feedback to user
            System.out.println("\nPlease enter the " + inpAnimalType + "'s gender as either Male or Female.");
        }
    } while (tmpGender == null); // this loop will continue until a valid gender in stored

    return tmpGender; // return the animal's gender as string
}


// Method to receive, validate, process, and return user input on the animal's age
public static String receiveUserInput_Age(Scanner scnr, String inpAnimalType) {
    String tmpAge = null; // local variable to store animal age

    do { // loop to receive and validate user input on the animal's age
        System.out.println("\nWhat is the " + inpAnimalType + "'s age?"); // prompt user for input

        try { // try loop to validate user input ensuring an integer is entered
            int userInpAge = Integer.parseInt(scnr.nextLine()); // grab next line and store as integer

            if (userInpAge >= 0) { // if user input is non-negative
                tmpAge = String.valueOf(userInpAge); // set local variable to user input
            }
            else { // if user input is negative, print the following feedback and hint
                System.out.println("\nPlease enter the " + inpAnimalType + "'s age as a whole number in years.");
                System.out.println("If the " + inpAnimalType + " is less than 1 year old, enter 0.");
            }
        }

        catch (Exception e) { // if the user input is invalid (not an integer), print the following feedback
            System.out.println("\nPlease enter the " + inpAnimalType + "'s age as a whole number in years.");
            System.out.println("If the " + inpAnimalType + " is less than 1 year old, enter 0.");
        }
    } while (tmpAge == null); // this loop with continue until a valid age is stored

    return tmpAge; // return the animal's age as string
}


// Method to receive, validate, process, and return user input on the animal's weight
public static String receiveUserInput_Weight(Scanner scnr, String inpAnimalType) {
    String tmpWeight = null; // local variable to store the animal weight

    do { // loop to receive and validate user input on the animal's weight
        System.out.println("\nWhat is the " + inpAnimalType + "'s weight?"); // prompt user for input

        try { // try loop to validate input and ensure the user enters a double
            double userInpWeight = Double.parseDouble(scnr.nextLine()); // store input as local variable

            if (userInpWeight > 0) { // if user input is greater than zero

                // rudimentary way to round a number to the nearest tenths place
                // multiply the number by 10, round it to the nearest ones, then divide by ten
                String workToFormat = String.valueOf((double)Math.round(userInpWeight * 10) / 10);

                // take the resulting string and find the index of the decimal
                int workToFormat_Decimal = workToFormat.indexOf(".");

                // truncate the rounded number to one decimal place and store the substring to local variable
                tmpWeight = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
            }
            else { // if the user entered a number equal to or less than zero, print feedback to user
                System.out.println("\nPlease enter the " + inpAnimalType + "'s weight as a number in pounds with one decimal.");
            }
        }

        catch (Exception e) { // if the user enters anything other than a double, print feedback to user
            System.out.println("\nPlease enter the " + inpAnimalType + "'s weight as a number in pounds with one decimal.");
        }

    } while (tmpWeight == null); // loop will continue until a valid entry is stored to local variable

    return tmpWeight; // return the animals weight as string
}


// Method to receive, validate, process, and return user input on the monkey's height
public static String receiveUserInput_MonkeyHeight(Scanner scnr) {
    String tmpHeight = null; // local variable to store the monkey height

    do { // loop to receive and validate user input on the monkey's height
        System.out.println("\nWhat is the monkey's height?"); // prompt user for input

        try { // try loop to validate input and ensure the user enters a double
            double userInpMonkeyHeight = Double.parseDouble(scnr.nextLine()); // store input as local variable

            if (userInpMonkeyHeight > 0) { // if user input is greater than zero

                // rudimentary way to round a number to the nearest tenths place
                // multiply the number by 10, round it to the nearest ones, then divide by ten
                String workToFormat = String.valueOf((double)Math.round(userInpMonkeyHeight * 10) / 10);

                // take the resulting string and find the index of the decimal
                int workToFormat_Decimal = workToFormat.indexOf(".");

                // truncate the rounded number to one decimal place and store the substring to local variable
                tmpHeight = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
            }
            else { // if the user entered a number equal to or less than zero, print feedback to user
                System.out.println("\nPlease enter the monkey's height as a number in inches with one decimal.");
            }
        }

        catch (Exception e) { // if the user enters anything other than a double, print feedback to user
            System.out.println("\nPlease enter the monkey's height as a number in inches with one decimal.");
        }
    } while (tmpHeight == null); // loop will continue until a valid entry is stored to local variable

    return tmpHeight; // return the animals height as string
}


// Method to receive, validate, process, and return user input on the monkey's body length
public static String receiveUserInput_MonkeyBodyLength(Scanner scnr) {
    String tmpBodyLength = null; // local variable to store the monkey body length

    do { // loop to receive and validate user input on the monkey's body length
        System.out.println("\nWhat is the monkey's body length?");

        try { // try loop to validate input and ensure the user enters a double
            double userInpMonkeyBodyLength = Double.parseDouble(scnr.nextLine()); // store input as local variable

            if (userInpMonkeyBodyLength > 0) { // if user input is greater than zero

                // rudimentary way to round a number to the nearest tenths place
                // multiply the number by 10, round it to the nearest ones, then divide by ten
                String workToFormat = String.valueOf((double)Math.round(userInpMonkeyBodyLength * 10) / 10);

                // take the resulting string and find the index of the decimal
                int workToFormat_Decimal = workToFormat.indexOf(".");

                // truncate the rounded number to one decimal place and store the substring to local variable
                tmpBodyLength = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
            }
            else { // if the user entered a number equal to or less than zero, print feedback to user
                System.out.println("\nPlease enter the monkey's body length as a number in inches with one decimal.");
            }
        }

        catch (Exception e) { // if the user enters anything other than a double, print feedback to user
            System.out.println("\nPlease enter the monkey's body length as a number in inches with one decimal.");
        }
    } while (tmpBodyLength == null); // loop will continue until a valid entry is stored to local variable

    return tmpBodyLength; // return the monkey body length as string
}


// Method to receive, validate, process, and return user input on the monkey's tail length
public static String receiveUserInput_MonkeyTailLength(Scanner scnr) {
    String tmpTailLength = null; // local variable to store the monkey tail length

    do { // loop to receive and validate user input on the monkey's tail length
        System.out.println("\nWhat is the monkey's tail length?");

        try { // try loop to validate input and ensure the user enters a double
            double userInpMonkeyTailLength = Double.parseDouble(scnr.nextLine()); // store input as local variable

            if (userInpMonkeyTailLength > 0) { // if user input is greater than zero

                // rudimentary way to round a number to the nearest tenths place
                // multiply the number by 10, round it to the nearest ones, then divide by ten
                String workToFormat = String.valueOf((double)Math.round(userInpMonkeyTailLength * 10) / 10);

                // take the resulting string and find the index of the decimal
                int workToFormat_Decimal = workToFormat.indexOf(".");

                // truncate the rounded number to one decimal place and store the substring to local variable
                tmpTailLength = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
            }
            else { // if the user entered a number equal to or less than zero, print feedback to user
                System.out.println("\nPlease enter the monkey's tail length as a number in inches with one decimal.");
            }
        }

        catch (Exception e) { // if the user enters anything other than a double, print feedback to user
            System.out.println("\nPlease enter the monkey's tail length as a number in inches with one decimal.");
        }
    } while (tmpTailLength == null); // loop will continue until a valid entry is stored to local variable

    return tmpTailLength; // return the monkey tail length as string
}


// Method to receive, validate, process, and return user input on the animal's acquisition date
public static String receiveUserInput_AcquisitionDate(Scanner scnr, String inpAnimalType) {
    String tmpAcqDate = null; // local variable to store animal acquisition date

    do { // loop to receive and validate user input on the animal's acquisition date
        System.out.println("\nWe'll need to know when the " + inpAnimalType + " was acquired.");

        // first, the user enters the year
        boolean yearCheck = false; // loop breaker to exit if year entry is valid
        while (!yearCheck) { // while year entry is invalid

            // prompt user for input on the year the animal was acquired
            System.out.println("\nEnter the year this " + inpAnimalType + " was acquired as YYYY:");

            try { // try loop to validate user input and ensure only an integer is entered
                int userInpAcqDate_Year = Integer.parseInt(scnr.nextLine()); // store as local variable

                // if the user enters an integer that is not 4 digits in length
                if ((userInpAcqDate_Year < 1000) || (userInpAcqDate_Year > 9999)) {
                    System.out.println("\nYour entry was invalid."); // print feedback
                    System.out.println("Please enter only the year and include exactly 4 digits."); // print hint
                }
                else { // if the user enter a 4 digit integer
                    tmpAcqDate = String.valueOf(userInpAcqDate_Year); // set local variable to user input
                    yearCheck = true; // toggle loop breaker to exit loop
                }
            }

            catch (Exception e) { // if user enters anything other than an integer, print the following feedback
                System.out.println("\nYour entry was invalid.");
                System.out.println("Please enter only the year and include exactly 4 digits.");
            }
        }

        // second, the user enters the month
        boolean monthCheck = false; // loop breaker to exit if month entry is valid
        while (!monthCheck) { // while month entry is invalid

            // prompt user for input on the month the animal was acquired
            System.out.println("\nEnter the month this " + inpAnimalType + " was acquired as MM:");

            try { // try loop to validate user input and ensure only an integer is entered
                int userInpAcqDate_Month = Integer.parseInt(scnr.nextLine()); // store as local variable

                // if the user enters an integer that is out of bounds (1-12)
                if ((userInpAcqDate_Month < 1) || (userInpAcqDate_Month > 12)) {
                    System.out.println("\nYour entry was invalid."); // print feedback
                    System.out.println("Please enter only the month and include exactly 2 digits."); // print hint
                }
                else { // if the user enters an integer is within bounds (1-12)
                    if (userInpAcqDate_Month < 10) { // if the number is less than 10
                        // add a zero to the string to keep formatting consistent (01 instead of 1)
                        // concatenate the user input for month followed by a hyphen and the year
                        tmpAcqDate = "0" + String.valueOf(userInpAcqDate_Month) + "-" + tmpAcqDate;
                    }
                    else { // if the number is not less than 10
                        // concatenate the user input for month followed by a hyphen and the year
                        tmpAcqDate = String.valueOf(userInpAcqDate_Month) + "-" + tmpAcqDate;
                    }
                    monthCheck = true; // toggle loop breaker to exit loop
                }
            }

            catch (Exception e) { // if user enters anything other than an integer, print the following feedback
                System.out.println("\nYour entry was invalid.");
                System.out.println("Please enter only the month and include exactly 2 digits.");
            }
        }

        // third, the user enters the day
        boolean dayCheck = false; // loop breaker to exit if day entry is valid
        while (!dayCheck) { // while day entry is invalid

            // prompt user for input on the day the animal was acquired
            System.out.println("\nEnter the day this " + inpAnimalType + " was acquired as DD:");

            try { // try loop to validate user input and ensure only an integer is entered
                int userInpAcqDate_Day = Integer.parseInt(scnr.nextLine()); // store as local variable

                // if the user enters an integer that is out of bounds (1-31)
                if ((userInpAcqDate_Day < 1) || (userInpAcqDate_Day > 31)) {
                    System.out.println("\nYour entry was invalid."); // print feedback
                    System.out.println("Please enter only the day and include exactly 2 digits."); // print hint
                }
                else { // if the user enters an integer is within bounds (1-31)
                    if (userInpAcqDate_Day < 10) { // if the number is less than 10
                        // add a zero to the string to keep formatting consistent (01 instead of 1)
                        // concatenate the user input for day followed by a hyphen and the month + year string
                        tmpAcqDate = "0" + String.valueOf(userInpAcqDate_Day) + "-" + tmpAcqDate;
                    }
                    else { // if the number is not less than 10
                        // concatenate the user input for day followed by a hyphen and the month + year string
                        tmpAcqDate = String.valueOf(userInpAcqDate_Day) + "-" + tmpAcqDate;
                    }
                    dayCheck = true; // toggle loop breaker to exit loop
                }
            }

            catch (Exception e) { // if user enters anything other than an integer, print the following feedback
                System.out.println("\nYour entry was invalid.");
                System.out.println("Please enter only the day and include exactly 2 digits.");
            }
        }
    } while (tmpAcqDate.length() != 10); // this loop will continue until the local variable is a 10 length string

    return tmpAcqDate; // return the acquisition date as string
}


// Method to receive, validate, process, and return user input on the animal's acquisition country
public static String receiveUserInput_AcquisitionCountry(Scanner scnr, String inpAnimalType) {
    String tmpAcqCountry = null; // local variable to store acquisition country

    do { // loop to receive and validate user input on the animal's country of origin
        System.out.println("\nIn what country was this " + inpAnimalType + " acquired?"); // prompt user for input

        boolean matchFound = false; // loop breaker that toggles when a match is found

        while (!matchFound) { // while no match has yet been found
            String userInpAcqCountry = scnr.nextLine(); // grab user input and store as local variable
            for (String country : listCountryNames) { // search list of country names
                if (country.equalsIgnoreCase(userInpAcqCountry)) { // if user input matches a country name
                    tmpAcqCountry = country; // set local variable to country name from database (better formatting)
                    matchFound = true; // toggle loop breaker to exit loop
                }
            }

            if (!matchFound) { // if no match was found, print the following feedback
                System.out.println("\nPlease enter the " + inpAnimalType + "'s acquisition country.");
                System.out.println("Be sure to use the correct spelling.");
            }
        }

    } while (tmpAcqCountry == null); // this loop will continue until a valid country name is stored

    return tmpAcqCountry; // return acquisition country as string
}


// Method to receive, validate, process, and return user input on the animal's training status
public static String receiveUserInput_TrainStatus(Scanner scnr, String inpAnimalType) {
    String tmpTrStat = null; // local variable to store animal training status

    do { // loop to receive and validate user input on the animal's training status
        System.out.println("\nWhat is this " + inpAnimalType + "'s training status?"); // prompt user for input
        System.out.println("If this " + inpAnimalType + " is new, please enter 'Intake'"); // print hint to user

        boolean matchFound = false; // loop breaker that toggles when a match is found

        while (!matchFound) { // while a match has yet to be found
            String userInpTrnStat = scnr.nextLine(); // grab user input and store as local variable
            for (String status : listTrainingStatus) { // search list of status options
                if (status.equalsIgnoreCase(userInpTrnStat)) { // if user input matches status from list
                    tmpTrStat = status; // set local variable to status from list (better formatting)
                    matchFound = true; // toggle the loop breaker to exit loop
                }
            }

            if (!matchFound) { // if no match is found, print the following feedback to user
                System.out.println("\nPlease enter the " + inpAnimalType + "'s training status as any of the following:");
                System.out.println("Intake, Phase I, Phase II, Phase III, Phase IV, Phase V, In Service, or Farm");
            }
        }

    } while (tmpTrStat == null); // this loop will continue until a valid entry is stored

    return tmpTrStat; // return the animal's training status as string
}


// Method to receive, validate, process, and return user input on the animal's reserved status
public static boolean receiveUserInput_Reserved(Scanner scnr, String inpAnimalType) {
    boolean tmpReserved = false; // local variable to store animal reserved status

    boolean animalResInpCheck = false; // loop breaker that toggles when input is valid

    do { // loop to receive and validate user input on the animal's availability
        System.out.println("\nIs this " + inpAnimalType + " currently reserved?"); // prompt user for input
        System.out.println("If this " + inpAnimalType + " is new, please enter 'false'"); // hint to user
        String userInpReserved = scnr.nextLine(); // grab user input and store as local variable

        // if user input is either 'true' or 'yes'...
        if (userInpReserved.equalsIgnoreCase("true") || userInpReserved.equalsIgnoreCase("yes")) {
            animalResInpCheck = true; // toggle loop breaker to exit loop
            tmpReserved = true; // update animal reserve status
        }

        // if user input is either 'false' or 'no'...
        else if (userInpReserved.equalsIgnoreCase("false") || userInpReserved.equalsIgnoreCase("no")) {
            animalResInpCheck = true; // toggle loop breaker to exit loop
        }
        else { // if the user enters anything other than 'true', 'false', 'yes', or 'no', print feedback
            System.out.println("\nPlease enter the " + inpAnimalType + "'s reservation status as either True or False.");
            System.out.println("You can also enter the " + inpAnimalType + "'s reservation status as either Yes or No.");
        }
    } while (!animalResInpCheck); // loop will continue until a valid entry is stored

    return tmpReserved; // return the animal's reserved status as boolean
}


// Method to receive, validate, process, and return user input on the animal's service country
public static String receiveUserInput_InServiceCountry(Scanner scnr, String inpAnimalType) {
    String tmpInSrvCountry = null;

    do { // loop to receive and validate user input on the animal's country of service
        System.out.println("\nWithin what country is this " + inpAnimalType + " working?"); // promt user for input

        boolean matchFound = false; // loop breaker that toggles when a match is found

        while (!matchFound) { // while no match has yet been found
            String userInpInSrvCountry = scnr.nextLine(); // grab user input and store as local variable
            for (String country : listCountryNames) { // search list of country names
                if (country.equalsIgnoreCase(userInpInSrvCountry)) { // if user input matches a country name
                    tmpInSrvCountry = country; // set local variable to country name from database (better formatting)
                    matchFound = true; // toggle loop breaker to exit loop
                }
            }

            if (!matchFound) { // if no match was found, print the following feedback
                System.out.println("\nPlease enter the " + inpAnimalType + "'s service country.");
                System.out.println("Be sure to use the correct spelling.");
            }
        }

    } while (tmpInSrvCountry == null); // this loop will continue until a valid country name is stored

    return tmpInSrvCountry; // return service country as string
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////