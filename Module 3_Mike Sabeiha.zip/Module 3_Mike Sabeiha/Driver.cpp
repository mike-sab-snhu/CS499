// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"
#include "Monkey.h"
#include "Dog.h"

using namespace std;

public class Driver { // establishing the driver class to hold main program

    // *Done* Instance variables (if needed)

    // Establishing Lists for data storage and input validation
    private static ArrayList<Dog> dogList = new ArrayList<Dog>(); // stores dog information
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>(); // stores monkey information
    private static String[] listTrainingStatus; // stores training status types
    private static String[] listMonkeySpecies; // stores monkey species types
    private static String[] listDogBreeds; // stores dog breed types
    private static String[] listCountryNames; // stores a list of country names

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // This section holds the main method
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);

        // lists are initialized by calling their methods
        initializeAttributeLists(); // initializes lists for validation checking
        initializeDogList(); // initializes lists for testing dog features
        initializeMonkeyList(); // initializes lists for testing monkey features

        // program starts
        displayMenu(); // menu is displayed but this method is not functional outside of printing
        runMenuLoop(scnr); // this calls the actual functions that serve as the core of the program

        return;
        // program ends
    }
}
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////; // stores a list of country names