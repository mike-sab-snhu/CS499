// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"
#include "Monkey.h"
#include "Dog.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds methods that handle the various components of the program
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // ***************  Complete!  ***************
    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list is done for you
public static void intakeNewDog(Scanner scnr) { // *Done* Hint: create a Scanner and pass it to the necessary methods
    String tmpName = null;
    String tmpBreed = null;
    String tmpGender = null;
    String tmpAge = null;
    String tmpWeight = null;
    String tmpAcqDate = null;
    String tmpAcqCountry = null;
    String tmpTrStat = null;
    boolean tmpReserved = false;
    String tmpInSrvCountry = null;

    // The following lines work through the intake questionnaire and store results as temporary variables
    // Each line receives input by calling a specific method then setting the variable to the result obtained

    tmpName = receiveUserInput_DogName(scnr); // GET DOG NAME FROM USER
    tmpBreed = receiveUserInput_DogBreed(scnr); // GET DOG BREED FROM USER
    tmpGender = receiveUserInput_Gender(scnr, "dog"); // GET DOG GENDER FROM USER
    tmpAge = receiveUserInput_Age(scnr, "dog"); // GET DOG AGE FROM USER
    tmpWeight = receiveUserInput_Weight(scnr, "dog"); // GET DOG WEIGHT FROM USER
    tmpAcqDate = receiveUserInput_AcquisitionDate(scnr, "dog"); // GET ACQUISITION DATE FROM USER
    tmpAcqCountry = receiveUserInput_AcquisitionCountry(scnr, "dog"); // GET DOG ACQUISITION COUNTRY FROM USER
    tmpTrStat = receiveUserInput_TrainStatus(scnr, "dog"); // GET DOG TRAINING STATUS FROM USER
    tmpReserved = receiveUserInput_Reserved(scnr, "dog"); // GET DOG RESERVED STATUS FROM USER
    tmpInSrvCountry = receiveUserInput_InServiceCountry(scnr, "dog"); // GET DOG IN SERVICE COUNTRY NAME FROM USER

    // *Done* Add the code to instantiate a new dog and add it to the appropriate list
    Dog dog = new Dog( // declares instance of dog object
        tmpName, // information formatted for convenience of reader
        tmpBreed,
        tmpGender,
        tmpAge,
        tmpWeight,
        tmpAcqDate,
        tmpAcqCountry,
        tmpTrStat,
        tmpReserved,
        tmpInSrvCountry);

    dogList.add(dog); // adds newly created dog to list of dogs

}


// ***************  Complete!  ***************
// Complete intakeNewMonkey
// Instantiate and add the new monkey to the appropriate list
// For the project submission you must also validate the input
// to make sure the monkey doesn't already exist and the species type is allowed
public static void intakeNewMonkey(Scanner scnr) { // *Done* Hint: create a Scanner and pass it to the necessary methods
    String tmpName = null;
    String tmpSpecies = null;
    String tmpGender = null;
    String tmpAge = null;
    String tmpHeight = null;
    String tmpBodyLength = null;
    String tmpTailLength = null;
    String tmpWeight = null;
    String tmpAcqDate = null;
    String tmpAcqCountry = null;
    String tmpTrStat = null;
    boolean tmpReserved = false;
    String tmpInSrvCountry = null;

    // The following lines work through the intake questionnaire and store results as temporary variables
    // Each line receives input by calling a specific method then setting the variable to the result obtained

    tmpName = receiveUserInput_MonkeyName(scnr); // GET MONKEY NAME FROM USER
    tmpSpecies = receiveUserInput_MonkeySpecies(scnr); // GET MONKEY SPECIES FROM USER
    if (tmpSpecies == null) { // exit to main menu if the user attempted to register an invalid monkey
        return;
    }
    tmpGender = receiveUserInput_Gender(scnr, "monkey"); // GET MONKEY GENDER FROM USER
    tmpAge = receiveUserInput_Age(scnr, "monkey"); // GET MONKEY AGE FROM USER
    tmpHeight = receiveUserInput_MonkeyHeight(scnr); // GET MONKEY HEIGHT FROM USER
    tmpBodyLength = receiveUserInput_MonkeyBodyLength(scnr); // GET MONKEY BODY LENGTH FROM USER
    tmpTailLength = receiveUserInput_MonkeyTailLength(scnr); // GET MONKEY TAIL LENGTH FROM USER
    tmpWeight = receiveUserInput_Weight(scnr, "monkey"); // GET MONKEY WEIGHT FROM USER
    tmpAcqDate = receiveUserInput_AcquisitionDate(scnr, "monkey"); // GET MONKEY ACQUISITION DATE FROM USER
    tmpAcqCountry = receiveUserInput_AcquisitionCountry(scnr, "monkey"); // GET MONKEY ACQUISITION COUNTRY FROM USER
    tmpTrStat = receiveUserInput_TrainStatus(scnr, "monkey"); // GET MONKEY TRAINING STATUS FROM USER
    tmpReserved = receiveUserInput_Reserved(scnr, "monkey"); // GET MONKEY RESERVED STATUS FROM USER
    tmpInSrvCountry = receiveUserInput_InServiceCountry(scnr, "monkey"); // GET MONKEY IN SERVICE COUNTRY NAME FROM USER

    // *Done* Add the code to instantiate a new monkey and add it to the appropriate list
    Monkey monkey = new Monkey( // declares instance of monkey object
        tmpName, // information formatted for convenience of reader
        tmpSpecies,
        tmpGender,
        tmpAge,
        tmpHeight,
        tmpBodyLength,
        tmpTailLength,
        tmpWeight,
        tmpAcqDate,
        tmpAcqCountry,
        tmpTrStat,
        tmpReserved,
        tmpInSrvCountry);

    monkeyList.add(monkey); // adds newly created monkey to list of dogs

}


// ***************  Complete!  ***************
// Complete reserveAnimal
// You will need to find the animal by animal type and in service country
public static void reserveAnimal(Scanner scnr) {
    String tmpAnimalName = null; // declaring local variable to store animal name for return to user
    String tmpAnimalType = null; // declaring local variable to store user input for animal type
    String tmpAnimalCountry = null; // declaring local variable to store user input for animal country

    // This section breaks down into two parts
    // Part one collects and validates the users input
    // Part two take that input and searches the database for matching entries

    // ==Part 1==

    // first do-while receives and validates user input on what type of animal they would like to reserve
    do {
        System.out.println("\nWhat type of animal would you like reserve"); // prompt to collect input

        String userInpAnimalType = scnr.nextLine(); // grabs line from user input as string

        // if the animal type matches either of the two types we manage
        if (userInpAnimalType.equalsIgnoreCase("monkey") || userInpAnimalType.equalsIgnoreCase("dog")) {
            tmpAnimalType = userInpAnimalType; // set the temporary variable to string from user input
        }
        else { // if the user input was neither of the two species we manage
            System.out.println("\nPlease enter either 'monkey' or 'dog'."); // print hint to correct input
        }
    } while (tmpAnimalType == null); // end loop if variable has value assigned

    // second do-while receives and validates user input on the service location they would like to reserve
    do {
        System.out.println("\nIn what country is this animal needed?"); // prompt to collect input

        String userInpAnimalCountry = scnr.nextLine(); // grabs line from user input as string

        boolean matchCountry = false; // checks results of loop, so it doesn't print feedback on each iteration

        for (String country : listCountryNames) { // searches list of country names to validate user input
            if (country.equalsIgnoreCase(userInpAnimalCountry)) { // if user input matches a country name
                tmpAnimalCountry = country; // set the temporary variable to string from loop (better formatting)
                matchCountry = true; // toggles the switch to keep feedback from printing
            }
        }

        if (!matchCountry) { // if there is no match and the switch stays off
            System.out.println("\nWe couldn't find that country in our database."); // print feedback
            System.out.println("Try again with correct spelling."); // print hint to correct input
        }

    } while (tmpAnimalCountry == null); // end loop if variable has value assigned

    // ==Part 2==

    // This if series takes the user input and searches the database for a match
    // I intentionally used the if series but a while loop might also work

    boolean foundAnimal = false; // switch that gets recycled by each if gate

    if (tmpAnimalType.equalsIgnoreCase("dog")) { // if the animal type is dog
        for (Dog dog : dogList) { // search dog list

            // the dog must be available, in target country, and have graduated their training
            if (!dog.getReserved() // if reserved is false
                && (dog.getInServiceLocation().equalsIgnoreCase(tmpAnimalCountry)) // if location matches
                && dog.getTrainingStatus().equalsIgnoreCase("in service")) { // if training graduated
                tmpAnimalName = dog.getName(); // set the variable to that dog's name
                dog.setReserved(true); // update that dog's reserved status
                foundAnimal = true; // toggle the switch for the next gate
            }
        }
    }

    else if (tmpAnimalType.equalsIgnoreCase("monkey")) { // if the animal type is monkey
        for (Monkey monkey : monkeyList) { // search monkey list

            // the monkey must be available, in target country, and have graduated their training
            if (!monkey.getReserved() // if reserved is false
                && (monkey.getInServiceLocation().equalsIgnoreCase(tmpAnimalCountry)) // if location matches
                && monkey.getTrainingStatus().equalsIgnoreCase("in service")) { // if training graduated
                tmpAnimalName = monkey.getName(); // set the variable to that monkey's name
                monkey.setReserved(true); // update that monkey's reserved status
                foundAnimal = true; // toggle the switch for the next gate
            }
        }
    }

    else { // if there is no type match for whatever reason
        return; // return to menu
    }

    if (foundAnimal) { // if there was a match found print the following feedback
        System.out.println("\nWe found a " + tmpAnimalType + " in " + tmpAnimalCountry + ".");
        System.out.println("Their name is " + tmpAnimalName + ".");
        System.out.println("Your reservation is complete.");
        return; // return to menu
    }
    else { // if there was no match found print the following feedback
        System.out.println("\nWe were not able to find a " + tmpAnimalType + " in " + tmpAnimalCountry + ".");
        System.out.println("It may be that we have no animals available.");
        System.out.println("It may also be that you entered the country name incorrectly.");
        System.out.println("You are welcome to try again with a different spelling.");
        return; // return to menu
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////