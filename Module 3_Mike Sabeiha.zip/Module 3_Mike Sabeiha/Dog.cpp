// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"

using namespace std;

class Dog : public RescueAnimal {
private:
    // Instance variable
    std::string breed;

public:
    // Constructor
    Dog(std::string name, std::string breed, std::string gender, std::string age,
        std::string weight, std::string acquisitionDate, std::string acquisitionCountry,
        std::string trainingStatus, bool reserved, std::string inServiceCountry) {

        // Using inherited setters from RescueAnimal
        setName(name);
        setBreed(breed);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
    }

    // Accessor Method (Getter)
    std::string getBreed() const {
        return breed;
    }

    // Mutator Method (Setter)
    void setBreed(const std::string& dogBreed) {
        breed = dogBreed;
    }
};
