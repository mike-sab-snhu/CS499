// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

using namespace std;

class RescueAnimal {
private:
    // Instance variables
    std::string name;
    std::string animalType;
    std::string gender;
    std::string age;
    std::string weight;
    std::string acquisitionDate;
    std::string acquisitionCountry;
    std::string trainingStatus;
    bool reserved;
    std::string inServiceCountry;

public:
    // Constructor
    RescueAnimal() : reserved(false) {}

    // Getters
    std::string getName() const { return name; }
    std::string getAnimalType() const { return animalType; }
    std::string getGender() const { return gender; }
    std::string getAge() const { return age; }
    std::string getWeight() const { return weight; }
    std::string getAcquisitionDate() const { return acquisitionDate; }
    std::string getAcquisitionLocation() const { return acquisitionCountry; }
    bool getReserved() const { return reserved; }
    std::string getInServiceLocation() const { return inServiceCountry; }
    std::string getTrainingStatus() const { return trainingStatus; }

    // Setters
    void setName(const std::string& name) { this->name = name; }
    void setAnimalType(const std::string& animalType) { this->animalType = animalType; }
    void setGender(const std::string& gender) { this->gender = gender; }
    void setAge(const std::string& age) { this->age = age; }
    void setWeight(const std::string& weight) { this->weight = weight; }
    void setAcquisitionDate(const std::string& acquisitionDate) { this->acquisitionDate = acquisitionDate; }
    void setAcquisitionLocation(const std::string& acquisitionCountry) { this->acquisitionCountry = acquisitionCountry; }
    void setReserved(bool reserved) { this->reserved = reserved; }
    void setInServiceCountry(const std::string& inServiceCountry) { this->inServiceCountry = inServiceCountry; }
    void setTrainingStatus(const std::string& trainingStatus) { this->trainingStatus = trainingStatus; }
};