// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"
#include "Monkey.h"
#include "Dog.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds the Menu Methods
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // This method prints the menu options
public static void displayMenu() {
    System.out.println("\n\n");
    System.out.println("\t\t\t\tRescue Animal System Menu");
    System.out.println("[1] Intake a new dog");
    System.out.println("[2] Intake a new monkey");
    System.out.println("[3] Reserve an animal");
    System.out.println("[4] Print a list of all dogs");
    System.out.println("[5] Print a list of all monkeys");
    System.out.println("[6] Print a list of all animals that are not reserved");
    System.out.println("[q] Quit application");
    System.out.println();
    System.out.println("Enter a menu selection");
}


// This method houses the functional program loop and serves as an operational hub
public static void runMenuLoop(Scanner scnr) {
    // ***************  Complete!  ***************
    // Add a loop that displays the menu, accepts the users input and takes the appropriate action.
    // For the project submission you must also include input validation and appropriate feedback to the user.
    boolean validCheck = false;
    do {
        try {
            String inpLine = scnr.nextLine();
            if (inpLine.length() > 1) {
                System.out.println("\nYour entry should only be one character in length.");
                System.out.println("Please enter a number from 1 to 6 or 'q' to quit.");
            }
            else {
                char inpChar = inpLine.charAt(0);
                if ((inpChar == 'q') || (inpChar == 'Q')) {
                    System.out.println("\nLooks like you're quitting for the day!");
                    System.out.println("The system will close once you press [enter].");
                    scnr.nextLine();
                    validCheck = true;
                }
                else {
                    if (((int)inpChar < 49) || ((int)inpChar > 54)) {
                        System.out.println("Please enter a number from 1 to 6 or 'q' to quit.");
                    }
                    else {
                        switch (inpChar) {
                        case '1':
                            System.out.println("\nMenu Item 1: Intake New Dog");
                            intakeNewDog(scnr);
                            break;
                        case '2':
                            System.out.println("\nMenu Item 2: Intake New Monkey");
                            intakeNewMonkey(scnr);
                            break;
                        case '3':
                            System.out.println("\nMenu Item 3: Reserve Animal");
                            reserveAnimal(scnr);
                            break;
                        case '4':
                            System.out.println("\nMenu Item 4: Print List of All Dogs");
                            printAnimals(1); // *Done* Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
                            break;
                        case '5':
                            System.out.println("\nMenu Item 5: Print List of All Monkeys");
                            printAnimals(2); // *Done* Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
                            break;
                        case '6':
                            System.out.println("\nMenu Item 6: Print List of All Available Animals");
                            printAnimals(3); // *Done* Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
                            break;
                        default:
                            System.out.println("\nDefault Case Error in Menu Option Selection");
                            break;
                        }
                        System.out.println("\nEnter a new command to continue or 'q' to exit.");
                    }
                }
            }
        }
        catch (Exception e) {
            System.out.println("Your entry cannot be blank.");
            System.out.println("Please enter a number from 1 to 6 or 'q' to quit.");
        }
    } while (!validCheck);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////