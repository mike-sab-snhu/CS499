// Mike Sabeiha
// SNHU: CS499
// Capstone
// Module 3: Improvements
// 2026 03 28

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

#include "RescueAnimal.h"
#include "Monkey.h"
#include "Dog.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds the print method which is kind of large on its own, so I separated it from the rest
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // ***************  Complete!  ***************
    // Complete printAnimals
    // Include the animal name, status, acquisition country and if the animal is reserved.
    // Remember that this method connects to three different menu items.

    // ***************  Complete!  ***************
    // The printAnimals() method has three different outputs based on the listType parameter
    //    dog - prints the list of dogs
    //    monkey - prints the list of monkeys
    //    available - prints a combined list of all animals that are fully trained ("in service") but not reserved

    // ***************  Complete!  ***************
    // Remember that you only have to fully implement ONE of these lists.
    // The other lists can have a print statement saying "This option needs to be implemented".
    // To score "exemplary" you must correctly implement the "available" list.
public static void printAnimals(int listType) {
    switch (listType) { // switch to select the output based on list type
    case 1: // this option prints the list of dogs
        System.out.println("\nTracking: ");
        System.out.println(dogList.size() + " Total Dog(s)"); // feedback on number of dogs
        System.out.println("\nPrinting list of All Dogs..."); // feedback for user convenience
        for (int i = 0; i < dogList.size(); i++) { // for loop to search list
            System.out.println("\nDog Number " + (i + 1)); // prints dog number
            System.out.println("\tName: " + dogList.get(i).getName()); // prints dog name
            System.out.println("\tStatus: " + dogList.get(i).getTrainingStatus()); // prints dog training status
            System.out.println("\tAcquisition Country: " + dogList.get(i).getAcquisitionLocation()); // prints dog acquisition location
            System.out.println("\tReserved: " + dogList.get(i).getReserved()); // prints dog reservation status
        }
        break;
    case 2: // this option prints the list of monkeys
        System.out.println("\nTracking: ");
        System.out.println(monkeyList.size() + " Total Monkey(s)"); // feedback on number of monkeys
        System.out.println("\nPrinting list of All Monkeys..."); // feedback for user convenience
        for (int i = 0; i < monkeyList.size(); i++) { // for loop to search list
            System.out.println("\nMonkey Number " + (i + 1)); // prints monkey number
            System.out.println("\tName: " + monkeyList.get(i).getName()); // prints monkey name
            System.out.println("\tStatus: " + monkeyList.get(i).getTrainingStatus()); // prints monkey training status
            System.out.println("\tAcquisition Country: " + monkeyList.get(i).getAcquisitionLocation()); // prints monkey acquisition location
            System.out.println("\tReserved: " + monkeyList.get(i).getReserved()); // prints monkey reservation status
        }
        break;
    case 3:
        // declaring local variables to track the number of animals in each category
        int totalAnimals = 0; // total number of animals being tacked
        int inServiceAnimals = 0; // number of animals in service
        int availableAnimals = 0; // number of in service animals that are available

        // totalAnimals is equal to the total number of animals being tracked by the organization
        totalAnimals = dogList.size() + monkeyList.size(); // equal to the sum of each list's length

        // inServiceAnimals is equal to the number of animals being tracked that have completed training
        for (Dog dog : dogList) { // first, the dog list is searched
            if (dog.getTrainingStatus().equalsIgnoreCase("In Service")) { // if training status is set to "in service"
                inServiceAnimals += 1; // the number of in service animals increments by 1
            }
        }
        for (Monkey monkey : monkeyList) { // next, the monkey list is searched
            if (monkey.getTrainingStatus().equalsIgnoreCase("In Service")) { // if training status is set to "in service"
                inServiceAnimals += 1; // the number of in service animals increments by 1
            }
        }

        // this loop searches both lists to find number of animals in service that are available
        for (Dog dog : dogList) { // first, the dog list is searched
            if (dog.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                && !dog.getReserved()) // and reserved status is false
            {
                availableAnimals += 1; // the number of in service animals increments by 1
            }
        }
        for (Monkey monkey : monkeyList) { // next, the monkey list is searched
            if (monkey.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                && !monkey.getReserved()) // and reserved status is false
            {
                availableAnimals += 1; // the number of in service animals increments by 1
            }
        }

        // this block of text provides feedback to the user on the organization's numbers
        System.out.println("\nTracking: ");
        System.out.println(totalAnimals + " Total Animal(s)"); // prints total animals
        System.out.println(inServiceAnimals + " In-Service"); // prints number of animals in service
        System.out.println(availableAnimals + " Available"); // prints number of animals available
        System.out.println("\nPrinting list of All Available Animals..."); // feedback for user convenience

        // this loop prints the compiled list of animals being tracked that are available for use
        while (availableAnimals > 0) { // counts down the total of available animals
            int counter = 1; // the tracks the chronology of animal information being printed
            for (Dog dog : dogList) { // first, the dog list is searched
                if (dog.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                    && !dog.getReserved()) // and reserved status is false
                {
                    System.out.println("\nAnimal Number " + counter); // prints animal number
                    System.out.println("\n\tAnimal Type: Dog\n"); // prints animal type
                    System.out.println("\tName: " + dog.getName()); // prints animal name
                    System.out.println("\tStatus: " + dog.getTrainingStatus()); // prints animal training status
                    System.out.println("\tAcquisition Country: " + dog.getAcquisitionLocation()); // prints animal acquisition location
                    System.out.println("\tReserved: " + dog.getReserved()); // prints animal reservation status
                    availableAnimals += -1; // decrements number of available animals
                    counter += 1; // increments the animal number
                }
            }
            for (Monkey monkey : monkeyList) { // next, the monkey list is searched
                if (monkey.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                    && !monkey.getReserved()) // and reserved status is false
                {
                    System.out.println("\nAnimal Number " + counter); // prints animal number continued from previous for loop
                    System.out.println("\n\tAnimal Type: Monkey\n"); // prints animal type
                    System.out.println("\tName: " + monkey.getName()); // prints animal name
                    System.out.println("\tStatus: " + monkey.getTrainingStatus()); // prints animal training status
                    System.out.println("\tAcquisition Country: " + monkey.getAcquisitionLocation()); // prints animal acquisition location
                    System.out.println("\tReserved: " + monkey.getReserved()); // prints animal reservation status
                    availableAnimals += -1; // decrements number of available animals
                    counter += 1; // increments the animal number
                }
            }
        }

        break;
    default:
        System.out.println("Default Case Error in Print List Method Call");
        break;
    }