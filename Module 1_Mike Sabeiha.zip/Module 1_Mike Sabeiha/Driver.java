import java.util.ArrayList; // import ArrayList from Utilities to store information
import java.util.Scanner; // import Scanner from Utilities to read user input

public class Driver { // establishing the driver class to hold main program

    // *Done* Instance variables (if needed)

    // Establishing Lists for data storage and input validation
    private static ArrayList<Dog> dogList = new ArrayList<Dog>(); // stores dog information
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>(); // stores monkey information
    private static String[] listTrainingStatus; // stores training status types
    private static String[] listMonkeySpecies; // stores monkey species types
    private static String[] listDogBreeds; // stores dog breed types
    private static String[] listCountryNames; // stores a list of country names

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds the main method
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);

        // lists are initialized by calling their methods
        initializeAttributeLists(); // initializes lists for validation checking
        initializeDogList(); // initializes lists for testing dog features
        initializeMonkeyList(); // initializes lists for testing monkey features

        // program starts
        displayMenu(); // menu is displayed but this method is not functional outside of printing
        runMenuLoop(scnr); // this calls the actual functions that serve as the core of the program

        return;
        // program ends
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds methods to initialize lists for both testing and validation
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "Intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "In Service", true, "Canada");
        Dog dog4 = new Dog("Rocker", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "In Service", false, "United States");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
        dogList.add(dog4);
    }


    // Adds monkeys to a list for testing
    public static void initializeMonkeyList() {
        Monkey monkey1 = new Monkey("Laugher", "Capuchin", "male", "2", "25.6", "14.5", "9.1", "25.2","05-12-2019", "United States", "Intake", false, "United States");
        Monkey monkey2 = new Monkey("Clapper", "Tamarin", "male", "3", "25.6", "14.5", "9.1", "25.2","05-12-2019", "United States", "Phase I", false, "United States");
        Monkey monkey3 = new Monkey("Smeller", "Macaque", "female", "7", "25.6", "14.5", "9.1", "25.2","05-12-2019", "United States", "In Service", false, "United States");
        Monkey monkey4 = new Monkey("Quacker", "Macaque", "female", "7", "25.6", "14.5", "9.1", "25.2","05-12-2019", "United States", "In Service", false, "United States");

        monkeyList.add(monkey1);
        monkeyList.add(monkey2);
        monkeyList.add(monkey3);
        monkeyList.add(monkey4);
    }


    // Adds strings to lists for validation checks
    public static void initializeAttributeLists () {

        // Adds training status types to training status list to validate user input
        listTrainingStatus = new String[]{
                "Intake", "Phase I", "Phase II", "Phase III", "Phase IV", "Phase V", "In Service", "Farm"};

        // Adds monkey species types to monkey species list to validate user input
        listMonkeySpecies = new String[]{"Capuchin", "Guenon", "Macaque", "Marmoset", "Squirrel Monkey", "Tamarin"};

        // Adds dog breed types to dog breed list to validate user input
        listDogBreeds = new String[]{"Unknown", "Mixed Breed", "Affenpinscher", "Afghan Hound", "Airedale Terrier",
        "Akita", "Alaskan Malamute", "American Staffordshire Terrier", "American Water Spaniel", "Australian Cattle Dog",
        "Australian Shepherd", "Australian Terrier", "Basenji", "Basset Hound", "Beagle", "Bearded Collie",
        "Bedlington Terrier", "Bernese Mountain Dog", "Bichon Frise", "Black And Tan Coonhound", "Bloodhound",
        "Border Collie", "Border Terrier", "Borzoi", "Boston Terrier", "Bouvier Des Flandres", "Boxer", "Briard",
        "Brittany", "Brussels Griffon", "Bull Terrier", "Bulldog", "Bullmastiff", "Cairn Terrier", "Canaan Dog",
        "Chesapeake Bay Retriever", "Chihuahua", "Chinese Crested", "Chinese Shar-Pei", "Chow Chow", "Clumber Spaniel",
        "Cocker Spaniel", "Collie", "Curly-Coated Retriever", "Dachshund", "Dalmatian", "Doberman Pinscher",
        "English Cocker Spaniel", "English Setter", "English Springer Spaniel", "English Toy Spaniel", "Eskimo Dog",
        "Finnish Spitz", "Flat-Coated Retriever", "Fox Terrier", "Foxhound", "French Bulldog", "German Shepherd",
        "German Shorthaired Pointer", "German Wirehaired Pointer", "Golden Retriever", "Gordon Setter", "Great Dane",
        "Greyhound", "Irish Setter", "Irish Water Spaniel", "Irish Wolfhound", "Jack Russell Terrier",
        "Japanese Spaniel", "Keeshond", "Kerry Blue Terrier", "Komondor", "Kuvasz", "Labrador Retriever",
        "Lakeland Terrier", "Lhasa Apso", "Maltese", "Manchester Terrier", "Mastiff", "Mexican Hairless",
        "Newfoundland", "Norwegian Elkhound", "Norwich Terrier", "Otterhound", "Papillon", "Pekingese", "Pointer",
        "Pomeranian", "Poodle", "Pug", "Puli", "Rhodesian Ridgeback", "Rottweiler", "Saint Bernard", "Saluki",
        "Samoyed", "Schipperke", "Schnauzer", "Scottish Deerhound", "Scottish Terrier", "Sealyham Terrier",
        "Shetland Sheepdog", "Shih Tzu", "Siberian Husky", "Silky Terrier", "Skye Terrier", "Staffordshire Bull Terrier",
        "Soft-Coated Wheaten Terrier", "Sussex Spaniel", "Spitz", "Tibetan Terrier", "Vizsla", "Weimaraner",
        "Welsh Terrier", "West Highland White Terrier", "Whippet", "Yorkshire Terrier", "Terrier", "Pit Bull"};

        // Adds country names to country name list to validate user input
        listCountryNames = new String[]{
        "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia",
        "Australia", "Austria", "Azerbaijan", "The Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium",
        "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria",
        "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic", "Chad",
        "Chile", "China", "Colombia", "Comoros", "The Congo",  "Costa Rica", "The Ivory Coast", "Croatia", "Cuba",
        "Cyprus", "Czechia", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt",
        "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France",
        "Gabon", "The Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea",
        "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq",
        "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "North Korea",
        "South Korea", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya",
        "Liechtenstein", "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta",
        "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia",
        "Montenegro", "Morocco", "Mozambique", "Myanmar", "Burma", "Namibia", "Nauru", "Nepal", "Netherlands",
        "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway", "Oman", "Pakistan", "Palau",
        "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania",
        "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa",
        "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone",
        "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "Spain", "Sri Lanka",
        "Sudan", "South Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania",
        "Thailand", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda",
        "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu",
        "Vatican City", "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"};
    }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds the Menu Methods
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // This method houses the functional program loop and serves as an operational hub
    public static void runMenuLoop(Scanner scnr) {
        // ***************  Complete!  ***************
        // Add a loop that displays the menu, accepts the users input and takes the appropriate action.
        // For the project submission you must also include input validation and appropriate feedback to the user.
        boolean validCheck = false;
        do {
            try {
                String inpLine = scnr.nextLine();
                if (inpLine.length() > 1) {
                    System.out.println("\nYour entry should only be one character in length.");
                    System.out.println("Please enter a number from 1 to 6 or 'q' to quit.");
                }
                else {
                    char inpChar = inpLine.charAt(0);
                    if ((inpChar == 'q') || (inpChar == 'Q')) {
                        System.out.println("\nLooks like you're quitting for the day!");
                        System.out.println("The system will close once you press [enter].");
                        scnr.nextLine();
                        validCheck = true;
                    } else {
                        if (((int) inpChar < 49) || ((int) inpChar > 54)) {
                            System.out.println("Please enter a number from 1 to 6 or 'q' to quit.");
                        } else {
                            switch (inpChar) {
                                case '1':
                                    System.out.println("\nMenu Item 1: Intake New Dog");
                                    intakeNewDog(scnr);
                                    break;
                                case '2':
                                    System.out.println("\nMenu Item 2: Intake New Monkey");
                                    intakeNewMonkey(scnr);
                                    break;
                                case '3':
                                    System.out.println("\nMenu Item 3: Reserve Animal");
                                    reserveAnimal(scnr);
                                    break;
                                case '4':
                                    System.out.println("\nMenu Item 4: Print List of All Dogs");
                                    printAnimals(1); // *Done* Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
                                    break;
                                case '5':
                                    System.out.println("\nMenu Item 5: Print List of All Monkeys");
                                    printAnimals(2); // *Done* Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
                                    break;
                                case '6':
                                    System.out.println("\nMenu Item 6: Print List of All Available Animals");
                                    printAnimals(3); // *Done* Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
                                    break;
                                default:
                                    System.out.println("\nDefault Case Error in Menu Option Selection");
                                    break;
                            }
                            System.out.println("\nEnter a new command to continue or 'q' to exit.");
                        }
                    }
                }
            }
            catch (Exception e) {
                System.out.println("Your entry cannot be blank.");
                System.out.println("Please enter a number from 1 to 6 or 'q' to quit.");
            }
        } while (!validCheck);
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds methods that handle the various components of the program
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // ***************  Complete!  ***************
    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list is done for you
    public static void intakeNewDog(Scanner scnr) { // *Done* Hint: create a Scanner and pass it to the necessary methods
        String tmpName = null;
        String tmpBreed = null;
        String tmpGender = null;
        String tmpAge = null;
        String tmpWeight = null;
        String tmpAcqDate = null;
        String tmpAcqCountry = null;
        String tmpTrStat = null;
        boolean tmpReserved = false;
        String tmpInSrvCountry = null;

        // The following lines work through the intake questionnaire and store results as temporary variables
        // Each line receives input by calling a specific method then setting the variable to the result obtained

        tmpName = receiveUserInput_DogName(scnr); // GET DOG NAME FROM USER
        tmpBreed = receiveUserInput_DogBreed(scnr); // GET DOG BREED FROM USER
        tmpGender = receiveUserInput_Gender(scnr, "dog"); // GET DOG GENDER FROM USER
        tmpAge = receiveUserInput_Age(scnr, "dog"); // GET DOG AGE FROM USER
        tmpWeight = receiveUserInput_Weight(scnr, "dog"); // GET DOG WEIGHT FROM USER
        tmpAcqDate = receiveUserInput_AcquisitionDate(scnr, "dog"); // GET ACQUISITION DATE FROM USER
        tmpAcqCountry = receiveUserInput_AcquisitionCountry(scnr, "dog"); // GET DOG ACQUISITION COUNTRY FROM USER
        tmpTrStat = receiveUserInput_TrainStatus(scnr, "dog"); // GET DOG TRAINING STATUS FROM USER
        tmpReserved = receiveUserInput_Reserved(scnr, "dog"); // GET DOG RESERVED STATUS FROM USER
        tmpInSrvCountry = receiveUserInput_InServiceCountry(scnr, "dog"); // GET DOG IN SERVICE COUNTRY NAME FROM USER

        // *Done* Add the code to instantiate a new dog and add it to the appropriate list
        Dog dog = new Dog( // declares instance of dog object
                tmpName, // information formatted for convenience of reader
                tmpBreed,
                tmpGender,
                tmpAge,
                tmpWeight,
                tmpAcqDate,
                tmpAcqCountry,
                tmpTrStat,
                tmpReserved,
                tmpInSrvCountry);

        dogList.add(dog); // adds newly created dog to list of dogs

    }


    // ***************  Complete!  ***************
    // Complete intakeNewMonkey
    // Instantiate and add the new monkey to the appropriate list
    // For the project submission you must also validate the input
    // to make sure the monkey doesn't already exist and the species type is allowed
    public static void intakeNewMonkey(Scanner scnr) { // *Done* Hint: create a Scanner and pass it to the necessary methods
        String tmpName = null;
        String tmpSpecies = null;
        String tmpGender = null;
        String tmpAge = null;
        String tmpHeight = null;
        String tmpBodyLength = null;
        String tmpTailLength = null;
        String tmpWeight = null;
        String tmpAcqDate = null;
        String tmpAcqCountry = null;
        String tmpTrStat = null;
        boolean tmpReserved = false;
        String tmpInSrvCountry = null;

        // The following lines work through the intake questionnaire and store results as temporary variables
        // Each line receives input by calling a specific method then setting the variable to the result obtained

        tmpName = receiveUserInput_MonkeyName(scnr); // GET MONKEY NAME FROM USER
        tmpSpecies = receiveUserInput_MonkeySpecies(scnr); // GET MONKEY SPECIES FROM USER
        if (tmpSpecies == null) { // exit to main menu if the user attempted to register an invalid monkey
            return;
        }
        tmpGender = receiveUserInput_Gender(scnr, "monkey"); // GET MONKEY GENDER FROM USER
        tmpAge = receiveUserInput_Age(scnr, "monkey") ; // GET MONKEY AGE FROM USER
        tmpHeight = receiveUserInput_MonkeyHeight(scnr); // GET MONKEY HEIGHT FROM USER
        tmpBodyLength = receiveUserInput_MonkeyBodyLength(scnr); // GET MONKEY BODY LENGTH FROM USER
        tmpTailLength = receiveUserInput_MonkeyTailLength(scnr); // GET MONKEY TAIL LENGTH FROM USER
        tmpWeight = receiveUserInput_Weight(scnr, "monkey"); // GET MONKEY WEIGHT FROM USER
        tmpAcqDate = receiveUserInput_AcquisitionDate(scnr, "monkey"); // GET MONKEY ACQUISITION DATE FROM USER
        tmpAcqCountry = receiveUserInput_AcquisitionCountry(scnr, "monkey"); // GET MONKEY ACQUISITION COUNTRY FROM USER
        tmpTrStat = receiveUserInput_TrainStatus(scnr, "monkey"); // GET MONKEY TRAINING STATUS FROM USER
        tmpReserved = receiveUserInput_Reserved(scnr, "monkey") ; // GET MONKEY RESERVED STATUS FROM USER
        tmpInSrvCountry = receiveUserInput_InServiceCountry(scnr, "monkey"); // GET MONKEY IN SERVICE COUNTRY NAME FROM USER

        // *Done* Add the code to instantiate a new monkey and add it to the appropriate list
        Monkey monkey = new Monkey( // declares instance of monkey object
                tmpName, // information formatted for convenience of reader
                tmpSpecies,
                tmpGender,
                tmpAge,
                tmpHeight,
                tmpBodyLength,
                tmpTailLength,
                tmpWeight,
                tmpAcqDate,
                tmpAcqCountry,
                tmpTrStat,
                tmpReserved,
                tmpInSrvCountry);

        monkeyList.add(monkey); // adds newly created monkey to list of dogs

    }


    // ***************  Complete!  ***************
    // Complete reserveAnimal
    // You will need to find the animal by animal type and in service country
    public static void reserveAnimal(Scanner scnr) {
        String tmpAnimalName = null; // declaring local variable to store animal name for return to user
        String tmpAnimalType = null; // declaring local variable to store user input for animal type
        String tmpAnimalCountry = null; // declaring local variable to store user input for animal country

        // This section breaks down into two parts
        // Part one collects and validates the users input
        // Part two take that input and searches the database for matching entries

        // ==Part 1==

        // first do-while receives and validates user input on what type of animal they would like to reserve
        do {
            System.out.println("\nWhat type of animal would you like reserve"); // prompt to collect input

            String userInpAnimalType = scnr.nextLine(); // grabs line from user input as string

            // if the animal type matches either of the two types we manage
            if (userInpAnimalType.equalsIgnoreCase("monkey") || userInpAnimalType.equalsIgnoreCase("dog")) {
                tmpAnimalType = userInpAnimalType; // set the temporary variable to string from user input
            }
            else { // if the user input was neither of the two species we manage
                System.out.println("\nPlease enter either 'monkey' or 'dog'."); // print hint to correct input
            }
        } while (tmpAnimalType == null); // end loop if variable has value assigned

        // second do-while receives and validates user input on the service location they would like to reserve
        do {
            System.out.println("\nIn what country is this animal needed?"); // prompt to collect input

            String userInpAnimalCountry = scnr.nextLine(); // grabs line from user input as string

            boolean matchCountry = false; // checks results of loop, so it doesn't print feedback on each iteration

            for (String country: listCountryNames) { // searches list of country names to validate user input
                if (country.equalsIgnoreCase(userInpAnimalCountry)) { // if user input matches a country name
                    tmpAnimalCountry = country; // set the temporary variable to string from loop (better formatting)
                    matchCountry = true; // toggles the switch to keep feedback from printing
                }
            }

            if (!matchCountry){ // if there is no match and the switch stays off
                System.out.println("\nWe couldn't find that country in our database."); // print feedback
                System.out.println("Try again with correct spelling."); // print hint to correct input
            }

        } while (tmpAnimalCountry == null); // end loop if variable has value assigned

        // ==Part 2==

        // This if series takes the user input and searches the database for a match
        // I intentionally used the if series but a while loop might also work

        boolean foundAnimal = false; // switch that gets recycled by each if gate

        if (tmpAnimalType.equalsIgnoreCase("dog")) { // if the animal type is dog
            for (Dog dog: dogList) { // search dog list

                // the dog must be available, in target country, and have graduated their training
                if (!dog.getReserved() // if reserved is false
                        && (dog.getInServiceLocation().equalsIgnoreCase(tmpAnimalCountry)) // if location matches
                        && dog.getTrainingStatus().equalsIgnoreCase("in service")) { // if training graduated
                    tmpAnimalName = dog.getName(); // set the variable to that dog's name
                    dog.setReserved(true); // update that dog's reserved status
                    foundAnimal = true; // toggle the switch for the next gate
                }
            }
        }

        else if (tmpAnimalType.equalsIgnoreCase("monkey")) { // if the animal type is monkey
            for (Monkey monkey: monkeyList) { // search monkey list

                // the monkey must be available, in target country, and have graduated their training
                if (!monkey.getReserved() // if reserved is false
                        && (monkey.getInServiceLocation().equalsIgnoreCase(tmpAnimalCountry)) // if location matches
                        && monkey.getTrainingStatus().equalsIgnoreCase("in service")) { // if training graduated
                    tmpAnimalName = monkey.getName(); // set the variable to that monkey's name
                    monkey.setReserved(true); // update that monkey's reserved status
                    foundAnimal = true; // toggle the switch for the next gate
                }
            }
        }

        else { // if there is no type match for whatever reason
            return; // return to menu
        }

        if (foundAnimal) { // if there was a match found print the following feedback
            System.out.println("\nWe found a " + tmpAnimalType + " in " + tmpAnimalCountry + ".");
            System.out.println("Their name is " + tmpAnimalName + ".");
            System.out.println("Your reservation is complete.");
            return; // return to menu
        }
        else { // if there was no match found print the following feedback
            System.out.println("\nWe were not able to find a " + tmpAnimalType + " in " + tmpAnimalCountry + ".");
            System.out.println("It may be that we have no animals available.");
            System.out.println("It may also be that you entered the country name incorrectly.");
            System.out.println("You are welcome to try again with a different spelling.");
            return; // return to menu
        }
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds the Intake Methods that prompt the user, validate input, process, and return
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // Method to receive, validate, process, and return user input on the dog's name
    public static String receiveUserInput_DogName (Scanner scnr) {
        String tmpName = null; // local variable to store dog's name

        do { // loop to receive and validate user input on the dog's name
            System.out.println("\nWhat is the dog's name?"); // prompt user to input name

            try { // try loop to ensure user enters valid string
                String userInpDogName = scnr.nextLine(); // grab next line
                for (Dog dog : dogList) { // checking to see if the dog name is already in use on our list
                    if (dog.getName().equalsIgnoreCase(userInpDogName)) { // if the dog name is in use
                        System.out.println("\nThis dog is already in our system."); // print feedback to user
                        System.out.println("You'll need to give them a unique name."); // print hint to user
                        System.out.println("Try adding a number to the end of their name."); // print hint to user
                    }
                    else { // if the dog name is not in use
                        tmpName = userInpDogName; // set the local variable to user input
                    }
                }
            }

            catch (Exception e) { // if the user makes an invalid entry
                System.out.println("Your entry cannot be blank."); // print feedback to user
                System.out.println("Please enter the dog's name."); // print feedback to user
            }
        } while (tmpName == null); // repeat loop until a valid entry is stored

        return tmpName; // return the dog name as string
    }


    //  Method to receive, validate, process, and return user input on the monkey's name
    public static String receiveUserInput_MonkeyName (Scanner scnr) {
        String tmpName = null; // local variable to store monkey's name

        do { // loop to receive and validate user input on the monkey's name
            System.out.println("\nWhat is the monkey's name?"); // prompt user to input name

            try { // try loop to ensure user enters valid string
                String userInpMonkeyName = scnr.nextLine(); // grab next line
                for (Monkey monkey : monkeyList) { // checking to see if the monkey name is already in use on our list
                    if (monkey.getName().equalsIgnoreCase(userInpMonkeyName)) { // if monkey name is in use
                        System.out.println("\nThis monkey is already in our system."); // print feedback to user
                        System.out.println("You'll need to give them a unique name."); // print hint to user
                        System.out.println("Try adding a number to the end of their name."); // print hint to user
                    }
                    else { // if the monkey name is not in use
                        tmpName = userInpMonkeyName; // set the local variable to user input
                    }
                }
            }

            catch (Exception e) { // if the user makes an invalid entry
                System.out.println("Your entry cannot be blank."); // print feedback to user
                System.out.println("Please enter the monkey's name."); // print feedback to user
            }
        } while (tmpName == null); // repeat loop until a valid entry is stored

        return tmpName; // return the monkey name as string
    }


    // Method to receive, validate, process, and return user input on the dog's breed
    public static String receiveUserInput_DogBreed (Scanner scnr) {
        String tmpBreed = null; // local variable to store dog's breed

        do { // loop to receive and validate user input on the dog's breed
            System.out.println("\nWhat is the dog's breed?"); // prompt user for input
            System.out.println("\nYou can enter 'Mixed Breed' or 'Unknown' if necessary."); // print hint to user

            boolean matchFound = false; // loop breaker based on whether a match was found

            while (!matchFound) { // while there is not yet a match found
                String userInpDogBreed = scnr.nextLine(); // grab the next line of user input
                for (String breed: listDogBreeds) { // search the list of dog breeds
                    if (breed.equalsIgnoreCase(userInpDogBreed)) { // if the user input matches a breed in the database
                        tmpBreed = breed; // set the local variable to that breed from database (better formatting)
                        matchFound = true; // set loop breaker to true
                    }
                }

                if (!matchFound) { // if no match was found and loop breaker is still false
                    System.out.println("\nPlease enter the dog's breed."); // prompt user for input
                    System.out.println("Be sure to use the correct spelling."); // print hint to user
                }
            } // this while loop repeats until a match is found

        } while (tmpBreed == null); // this do-while repeats until a valid breed bas been store to local variable

        return tmpBreed; // returns dog breed as string
    }


    // Method to receive, validate, process, and return user input on the monkey's species
    public static String receiveUserInput_MonkeySpecies (Scanner scnr) {
        String tmpSpecies = null; // local variable to store monkey species

        do { // loop to receive and validate user input on the Monkey's species
            System.out.println("\nWe'll need to know the monkey's species."); // inform user about next steps
            System.out.println("\nWe can only accept the following:"); // print hint to user
            System.out.println("Capuchin, Guenon, Macaque, Marmoset, Squirrel Monkey, or Tamarin."); // print options
            System.out.println("\nIs your monkey's species on this list?"); // prompt user for yes/no input

            String userInpMonkeyCheck = scnr.nextLine(); // grab next line from user input and store as local variable

            // if the user input is neither 'yes' nor 'no'...
            if (!(userInpMonkeyCheck.equalsIgnoreCase("yes") || userInpMonkeyCheck.equalsIgnoreCase("no"))) {
                System.out.println("\nPlease enter 'yes' or 'no'."); // prompt user for input
            }
            else{ // if the user input is either 'yes' or 'no'...

                // if the user's monkey species is on the list...
                if (userInpMonkeyCheck.equalsIgnoreCase("yes")) {
                    System.out.println("\nWhat is the Monkey's Species?"); // prompt user for input

                    boolean matchFound = false; // loop breaker that toggles when match is found

                    while (!matchFound) { // while a match has yet to be found
                        String userInpMonkeySpecies = scnr.nextLine(); // grab user input and store as local variable
                        for (String species: listMonkeySpecies) { // search list of monkey species
                            if (species.equalsIgnoreCase(userInpMonkeySpecies)) { // if user input matches a species
                                tmpSpecies = species; // set the temporary variable to the species
                                matchFound = true; // toggle loop breaker to exit loop
                            }
                        }

                        if (!matchFound)  { // if no match was found, prompt the user with the following
                            System.out.println("\nPlease enter the monkey's species as any of the following:");
                            System.out.println("Capuchin, Guenon, Macaque, Marmoset, Squirrel Monkey, or Tamarin.");
                        }
                    }
                }

                else { // if the user's monkey species is not on the list
                    System.out.println("\nWe cannot accept your monkey."); // print feedback to user
                    System.out.println("\nYou'll be returned to the main menu now."); // print feedback to user
                    break; // break to menu
                }
            }
        } while (tmpSpecies == null); // this loop will continue until a valid special is stored

        return tmpSpecies; // return the monkey species as string
    }


    // Method to receive, validate, process, and return user input on the animal's gender
    public static String receiveUserInput_Gender (Scanner scnr, String inpAnimalType) {
        String tmpGender = null; // local variable to store animal gender

        do { // loop to receive and validate user input on the animal's gender
            System.out.println("\nWhat is the " + inpAnimalType + "'s gender?"); // prompt user for input
            String userInpGender = scnr.nextLine(); // grab user input and store as local variable

            // if the user input is either 'male' or 'female'...
            if (userInpGender.equalsIgnoreCase("male") || userInpGender.equalsIgnoreCase("female")) {
                tmpGender = userInpGender; // set the local variable to user input
            }
            else { // if the user input is neither 'male' nor 'female', print feedback to user
                System.out.println("\nPlease enter the " + inpAnimalType + "'s gender as either Male or Female.");
            }
        } while (tmpGender == null); // this loop will continue until a valid gender in stored

        return tmpGender; // return the animal's gender as string
    }


    // Method to receive, validate, process, and return user input on the animal's age
    public static String receiveUserInput_Age (Scanner scnr, String inpAnimalType) {
        String tmpAge = null; // local variable to store animal age

        do { // loop to receive and validate user input on the animal's age
            System.out.println("\nWhat is the " + inpAnimalType + "'s age?"); // prompt user for input

            try { // try loop to validate user input ensuring an integer is entered
                int userInpAge = Integer.parseInt(scnr.nextLine()); // grab next line and store as integer

                if (userInpAge >= 0) { // if user input is non-negative
                    tmpAge = String.valueOf(userInpAge); // set local variable to user input
                }
                else { // if user input is negative, print the following feedback and hint
                    System.out.println("\nPlease enter the " + inpAnimalType + "'s age as a whole number in years.");
                    System.out.println("If the " + inpAnimalType + " is less than 1 year old, enter 0.");
                }
            }

            catch (Exception e) { // if the user input is invalid (not an integer), print the following feedback
                System.out.println("\nPlease enter the " + inpAnimalType + "'s age as a whole number in years.");
                System.out.println("If the " + inpAnimalType + " is less than 1 year old, enter 0.");
            }
        } while (tmpAge == null); // this loop with continue until a valid age is stored

        return tmpAge; // return the animal's age as string
    }


    // Method to receive, validate, process, and return user input on the animal's weight
    public static String receiveUserInput_Weight (Scanner scnr, String inpAnimalType) {
        String tmpWeight = null; // local variable to store the animal weight

        do { // loop to receive and validate user input on the animal's weight
            System.out.println("\nWhat is the " + inpAnimalType + "'s weight?"); // prompt user for input

            try { // try loop to validate input and ensure the user enters a double
                double userInpWeight = Double.parseDouble(scnr.nextLine()); // store input as local variable

                if (userInpWeight > 0) { // if user input is greater than zero

                    // rudimentary way to round a number to the nearest tenths place
                    // multiply the number by 10, round it to the nearest ones, then divide by ten
                    String workToFormat = String.valueOf((double) Math.round(userInpWeight * 10) / 10);

                    // take the resulting string and find the index of the decimal
                    int workToFormat_Decimal = workToFormat.indexOf(".");

                    // truncate the rounded number to one decimal place and store the substring to local variable
                    tmpWeight = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
                }
                else { // if the user entered a number equal to or less than zero, print feedback to user
                    System.out.println("\nPlease enter the " + inpAnimalType + "'s weight as a number in pounds with one decimal.");
                }
            }

            catch (Exception e) { // if the user enters anything other than a double, print feedback to user
                System.out.println("\nPlease enter the " + inpAnimalType + "'s weight as a number in pounds with one decimal.");
            }

        } while (tmpWeight == null); // loop will continue until a valid entry is stored to local variable

        return tmpWeight; // return the animals weight as string
    }


    // Method to receive, validate, process, and return user input on the monkey's height
    public static String receiveUserInput_MonkeyHeight (Scanner scnr) {
        String tmpHeight = null; // local variable to store the monkey height

        do { // loop to receive and validate user input on the monkey's height
            System.out.println("\nWhat is the monkey's height?"); // prompt user for input

            try { // try loop to validate input and ensure the user enters a double
                double userInpMonkeyHeight = Double.parseDouble(scnr.nextLine()); // store input as local variable

                if (userInpMonkeyHeight > 0) { // if user input is greater than zero

                    // rudimentary way to round a number to the nearest tenths place
                    // multiply the number by 10, round it to the nearest ones, then divide by ten
                    String workToFormat = String.valueOf((double) Math.round(userInpMonkeyHeight * 10) / 10);

                    // take the resulting string and find the index of the decimal
                    int workToFormat_Decimal = workToFormat.indexOf(".");

                    // truncate the rounded number to one decimal place and store the substring to local variable
                    tmpHeight = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
                }
                else { // if the user entered a number equal to or less than zero, print feedback to user
                    System.out.println("\nPlease enter the monkey's height as a number in inches with one decimal.");
                }
            }

            catch (Exception e) { // if the user enters anything other than a double, print feedback to user
                System.out.println("\nPlease enter the monkey's height as a number in inches with one decimal.");
            }
        } while (tmpHeight == null); // loop will continue until a valid entry is stored to local variable

        return tmpHeight; // return the animals height as string
    }


    // Method to receive, validate, process, and return user input on the monkey's body length
    public static String receiveUserInput_MonkeyBodyLength (Scanner scnr) {
        String tmpBodyLength = null; // local variable to store the monkey body length

        do { // loop to receive and validate user input on the monkey's body length
            System.out.println("\nWhat is the monkey's body length?");

            try { // try loop to validate input and ensure the user enters a double
                double userInpMonkeyBodyLength = Double.parseDouble(scnr.nextLine()); // store input as local variable

                if (userInpMonkeyBodyLength > 0) { // if user input is greater than zero

                    // rudimentary way to round a number to the nearest tenths place
                    // multiply the number by 10, round it to the nearest ones, then divide by ten
                    String workToFormat = String.valueOf((double) Math.round(userInpMonkeyBodyLength * 10) / 10);

                    // take the resulting string and find the index of the decimal
                    int workToFormat_Decimal = workToFormat.indexOf(".");

                    // truncate the rounded number to one decimal place and store the substring to local variable
                    tmpBodyLength = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
                }
                else { // if the user entered a number equal to or less than zero, print feedback to user
                    System.out.println("\nPlease enter the monkey's body length as a number in inches with one decimal.");
                }
            }

            catch (Exception e) { // if the user enters anything other than a double, print feedback to user
                System.out.println("\nPlease enter the monkey's body length as a number in inches with one decimal.");
            }
        } while (tmpBodyLength == null); // loop will continue until a valid entry is stored to local variable

        return tmpBodyLength; // return the monkey body length as string
    }


    // Method to receive, validate, process, and return user input on the monkey's tail length
    public static String receiveUserInput_MonkeyTailLength (Scanner scnr) {
        String tmpTailLength = null; // local variable to store the monkey tail length

        do { // loop to receive and validate user input on the monkey's tail length
            System.out.println("\nWhat is the monkey's tail length?");

            try { // try loop to validate input and ensure the user enters a double
                double userInpMonkeyTailLength = Double.parseDouble(scnr.nextLine()); // store input as local variable

                if (userInpMonkeyTailLength > 0) { // if user input is greater than zero

                    // rudimentary way to round a number to the nearest tenths place
                    // multiply the number by 10, round it to the nearest ones, then divide by ten
                    String workToFormat = String.valueOf((double) Math.round(userInpMonkeyTailLength * 10) / 10);

                    // take the resulting string and find the index of the decimal
                    int workToFormat_Decimal = workToFormat.indexOf(".");

                    // truncate the rounded number to one decimal place and store the substring to local variable
                    tmpTailLength = String.valueOf(workToFormat.substring(0, workToFormat_Decimal + 2));
                }
                else { // if the user entered a number equal to or less than zero, print feedback to user
                    System.out.println("\nPlease enter the monkey's tail length as a number in inches with one decimal.");
                }
            }

            catch (Exception e) { // if the user enters anything other than a double, print feedback to user
                System.out.println("\nPlease enter the monkey's tail length as a number in inches with one decimal.");
            }
        } while (tmpTailLength == null); // loop will continue until a valid entry is stored to local variable

        return tmpTailLength; // return the monkey tail length as string
    }


    // Method to receive, validate, process, and return user input on the animal's acquisition date
    public static String receiveUserInput_AcquisitionDate (Scanner scnr, String inpAnimalType) {
        String tmpAcqDate = null; // local variable to store animal acquisition date

        do { // loop to receive and validate user input on the animal's acquisition date
            System.out.println("\nWe'll need to know when the " + inpAnimalType + " was acquired.");

            // first, the user enters the year
            boolean yearCheck = false; // loop breaker to exit if year entry is valid
            while (!yearCheck) { // while year entry is invalid

                // prompt user for input on the year the animal was acquired
                System.out.println("\nEnter the year this " + inpAnimalType + " was acquired as YYYY:");

                try { // try loop to validate user input and ensure only an integer is entered
                    int userInpAcqDate_Year = Integer.parseInt(scnr.nextLine()); // store as local variable

                    // if the user enters an integer that is not 4 digits in length
                    if ((userInpAcqDate_Year < 1000) || (userInpAcqDate_Year > 9999)) {
                        System.out.println("\nYour entry was invalid."); // print feedback
                        System.out.println("Please enter only the year and include exactly 4 digits."); // print hint
                    } else { // if the user enter a 4 digit integer
                        tmpAcqDate = String.valueOf(userInpAcqDate_Year); // set local variable to user input
                        yearCheck = true; // toggle loop breaker to exit loop
                    }
                }

                catch (Exception e) { // if user enters anything other than an integer, print the following feedback
                    System.out.println("\nYour entry was invalid.");
                    System.out.println("Please enter only the year and include exactly 4 digits.");
                }
            }

            // second, the user enters the month
            boolean monthCheck = false; // loop breaker to exit if month entry is valid
            while (!monthCheck) { // while month entry is invalid

                // prompt user for input on the month the animal was acquired
                System.out.println("\nEnter the month this " + inpAnimalType + " was acquired as MM:");

                try { // try loop to validate user input and ensure only an integer is entered
                    int userInpAcqDate_Month = Integer.parseInt(scnr.nextLine()); // store as local variable

                    // if the user enters an integer that is out of bounds (1-12)
                    if ((userInpAcqDate_Month < 1) || (userInpAcqDate_Month > 12)) {
                        System.out.println("\nYour entry was invalid."); // print feedback
                        System.out.println("Please enter only the month and include exactly 2 digits."); // print hint
                    } else { // if the user enters an integer is within bounds (1-12)
                        if (userInpAcqDate_Month < 10) { // if the number is less than 10
                            // add a zero to the string to keep formatting consistent (01 instead of 1)
                            // concatenate the user input for month followed by a hyphen and the year
                            tmpAcqDate = "0" + String.valueOf(userInpAcqDate_Month) + "-" + tmpAcqDate;
                        } else { // if the number is not less than 10
                            // concatenate the user input for month followed by a hyphen and the year
                            tmpAcqDate = String.valueOf(userInpAcqDate_Month) + "-" + tmpAcqDate;
                        }
                        monthCheck = true; // toggle loop breaker to exit loop
                    }
                }

                catch (Exception e) { // if user enters anything other than an integer, print the following feedback
                    System.out.println("\nYour entry was invalid.");
                    System.out.println("Please enter only the month and include exactly 2 digits.");
                }
            }

            // third, the user enters the day
            boolean dayCheck = false; // loop breaker to exit if day entry is valid
            while (!dayCheck) { // while day entry is invalid

                // prompt user for input on the day the animal was acquired
                System.out.println("\nEnter the day this " + inpAnimalType + " was acquired as DD:");

                try { // try loop to validate user input and ensure only an integer is entered
                    int userInpAcqDate_Day = Integer.parseInt(scnr.nextLine()); // store as local variable

                    // if the user enters an integer that is out of bounds (1-31)
                    if ((userInpAcqDate_Day < 1) || (userInpAcqDate_Day > 31)) {
                        System.out.println("\nYour entry was invalid."); // print feedback
                        System.out.println("Please enter only the day and include exactly 2 digits."); // print hint
                    } else { // if the user enters an integer is within bounds (1-31)
                        if (userInpAcqDate_Day < 10) { // if the number is less than 10
                            // add a zero to the string to keep formatting consistent (01 instead of 1)
                            // concatenate the user input for day followed by a hyphen and the month + year string
                            tmpAcqDate = "0" + String.valueOf(userInpAcqDate_Day) + "-" + tmpAcqDate;
                        } else { // if the number is not less than 10
                            // concatenate the user input for day followed by a hyphen and the month + year string
                            tmpAcqDate = String.valueOf(userInpAcqDate_Day) + "-" + tmpAcqDate;
                        }
                        dayCheck = true; // toggle loop breaker to exit loop
                    }
                }

                catch (Exception e) { // if user enters anything other than an integer, print the following feedback
                    System.out.println("\nYour entry was invalid.");
                    System.out.println("Please enter only the day and include exactly 2 digits.");
                }
            }
        } while (tmpAcqDate.length() != 10); // this loop will continue until the local variable is a 10 length string

        return tmpAcqDate; // return the acquisition date as string
    }


    // Method to receive, validate, process, and return user input on the animal's acquisition country
    public static String receiveUserInput_AcquisitionCountry (Scanner scnr, String inpAnimalType) {
        String tmpAcqCountry = null; // local variable to store acquisition country

        do { // loop to receive and validate user input on the animal's country of origin
            System.out.println("\nIn what country was this " + inpAnimalType + " acquired?"); // prompt user for input

            boolean matchFound = false; // loop breaker that toggles when a match is found

            while (!matchFound) { // while no match has yet been found
                String userInpAcqCountry = scnr.nextLine(); // grab user input and store as local variable
                for (String country: listCountryNames) { // search list of country names
                    if (country.equalsIgnoreCase(userInpAcqCountry)) { // if user input matches a country name
                        tmpAcqCountry = country; // set local variable to country name from database (better formatting)
                        matchFound = true; // toggle loop breaker to exit loop
                    }
                }

                if (!matchFound) { // if no match was found, print the following feedback
                    System.out.println("\nPlease enter the " + inpAnimalType + "'s acquisition country.");
                    System.out.println("Be sure to use the correct spelling.");
                }
            }

        } while (tmpAcqCountry == null); // this loop will continue until a valid country name is stored

        return tmpAcqCountry; // return acquisition country as string
    }


    // Method to receive, validate, process, and return user input on the animal's training status
    public static String receiveUserInput_TrainStatus (Scanner scnr, String inpAnimalType) {
        String tmpTrStat = null; // local variable to store animal training status

        do { // loop to receive and validate user input on the animal's training status
            System.out.println("\nWhat is this " + inpAnimalType + "'s training status?"); // prompt user for input
            System.out.println("If this " + inpAnimalType + " is new, please enter 'Intake'"); // print hint to user

            boolean matchFound = false; // loop breaker that toggles when a match is found

            while (!matchFound) { // while a match has yet to be found
                String userInpTrnStat = scnr.nextLine(); // grab user input and store as local variable
                for (String status: listTrainingStatus) { // search list of status options
                    if (status.equalsIgnoreCase(userInpTrnStat)) { // if user input matches status from list
                        tmpTrStat = status; // set local variable to status from list (better formatting)
                        matchFound = true; // toggle the loop breaker to exit loop
                    }
                }

                if (!matchFound) { // if no match is found, print the following feedback to user
                    System.out.println("\nPlease enter the " + inpAnimalType + "'s training status as any of the following:");
                    System.out.println("Intake, Phase I, Phase II, Phase III, Phase IV, Phase V, In Service, or Farm");
                }
            }

        } while (tmpTrStat == null); // this loop will continue until a valid entry is stored

        return tmpTrStat; // return the animal's training status as string
    }


    // Method to receive, validate, process, and return user input on the animal's reserved status
    public static boolean receiveUserInput_Reserved (Scanner scnr, String inpAnimalType) {
        boolean tmpReserved = false; // local variable to store animal reserved status

        boolean animalResInpCheck = false; // loop breaker that toggles when input is valid

        do { // loop to receive and validate user input on the animal's availability
            System.out.println("\nIs this " + inpAnimalType + " currently reserved?"); // prompt user for input
            System.out.println("If this " + inpAnimalType + " is new, please enter 'false'"); // hint to user
            String userInpReserved = scnr.nextLine(); // grab user input and store as local variable

            // if user input is either 'true' or 'yes'...
            if (userInpReserved.equalsIgnoreCase("true") || userInpReserved.equalsIgnoreCase("yes")) {
                animalResInpCheck = true; // toggle loop breaker to exit loop
                tmpReserved = true; // update animal reserve status
            }

            // if user input is either 'false' or 'no'...
            else if (userInpReserved.equalsIgnoreCase("false") || userInpReserved.equalsIgnoreCase("no")) {
                animalResInpCheck = true; // toggle loop breaker to exit loop
            }
            else { // if the user enters anything other than 'true', 'false', 'yes', or 'no', print feedback
                System.out.println("\nPlease enter the " + inpAnimalType + "'s reservation status as either True or False.");
                System.out.println("You can also enter the " + inpAnimalType + "'s reservation status as either Yes or No.");
            }
        } while (!animalResInpCheck); // loop will continue until a valid entry is stored

        return tmpReserved; // return the animal's reserved status as boolean
    }


    // Method to receive, validate, process, and return user input on the animal's service country
    public static String receiveUserInput_InServiceCountry (Scanner scnr, String inpAnimalType) {
        String tmpInSrvCountry = null;

        do { // loop to receive and validate user input on the animal's country of service
            System.out.println("\nWithin what country is this " + inpAnimalType + " working?"); // promt user for input

            boolean matchFound = false; // loop breaker that toggles when a match is found

            while (!matchFound) { // while no match has yet been found
                String userInpInSrvCountry = scnr.nextLine(); // grab user input and store as local variable
                for (String country: listCountryNames) { // search list of country names
                    if (country.equalsIgnoreCase(userInpInSrvCountry)) { // if user input matches a country name
                        tmpInSrvCountry = country; // set local variable to country name from database (better formatting)
                        matchFound = true; // toggle loop breaker to exit loop
                    }
                }

                if (!matchFound) { // if no match was found, print the following feedback
                    System.out.println("\nPlease enter the " + inpAnimalType + "'s service country.");
                    System.out.println("Be sure to use the correct spelling.");
                }
            }

        } while (tmpInSrvCountry == null); // this loop will continue until a valid country name is stored

        return tmpInSrvCountry; // return service country as string
    }



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // This section holds the print method which is kind of large on its own, so I separated it from the rest
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // ***************  Complete!  ***************
    // Complete printAnimals
    // Include the animal name, status, acquisition country and if the animal is reserved.
    // Remember that this method connects to three different menu items.

    // ***************  Complete!  ***************
    // The printAnimals() method has three different outputs based on the listType parameter
    //    dog - prints the list of dogs
    //    monkey - prints the list of monkeys
    //    available - prints a combined list of all animals that are fully trained ("in service") but not reserved

    // ***************  Complete!  ***************
    // Remember that you only have to fully implement ONE of these lists.
    // The other lists can have a print statement saying "This option needs to be implemented".
    // To score "exemplary" you must correctly implement the "available" list.
    public static void printAnimals(int listType) {
        switch (listType) { // switch to select the output based on list type
            case 1: // this option prints the list of dogs
                System.out.println("\nTracking: ");
                System.out.println(dogList.size() + " Total Dog(s)"); // feedback on number of dogs
                System.out.println("\nPrinting list of All Dogs..."); // feedback for user convenience
                for (int i = 0; i < dogList.size(); i++) { // for loop to search list
                    System.out.println("\nDog Number " + (i + 1)); // prints dog number
                    System.out.println("\tName: " + dogList.get(i).getName()); // prints dog name
                    System.out.println("\tStatus: " + dogList.get(i).getTrainingStatus()); // prints dog training status
                    System.out.println("\tAcquisition Country: " + dogList.get(i).getAcquisitionLocation()); // prints dog acquisition location
                    System.out.println("\tReserved: " + dogList.get(i).getReserved()); // prints dog reservation status
                }
                break;
            case 2: // this option prints the list of monkeys
                System.out.println("\nTracking: ");
                System.out.println(monkeyList.size() + " Total Monkey(s)"); // feedback on number of monkeys
                System.out.println("\nPrinting list of All Monkeys..."); // feedback for user convenience
                for (int i = 0; i < monkeyList.size(); i++) { // for loop to search list
                    System.out.println("\nMonkey Number " + (i + 1)); // prints monkey number
                    System.out.println("\tName: " + monkeyList.get(i).getName()); // prints monkey name
                    System.out.println("\tStatus: " + monkeyList.get(i).getTrainingStatus()); // prints monkey training status
                    System.out.println("\tAcquisition Country: " + monkeyList.get(i).getAcquisitionLocation()); // prints monkey acquisition location
                    System.out.println("\tReserved: " + monkeyList.get(i).getReserved()); // prints monkey reservation status
                }
                break;
            case 3:
                // declaring local variables to track the number of animals in each category
                int totalAnimals = 0; // total number of animals being tacked
                int inServiceAnimals = 0; // number of animals in service
                int availableAnimals = 0; // number of in service animals that are available

                // totalAnimals is equal to the total number of animals being tracked by the organization
                totalAnimals = dogList.size() + monkeyList.size(); // equal to the sum of each list's length

                // inServiceAnimals is equal to the number of animals being tracked that have completed training
                for (Dog dog: dogList) { // first, the dog list is searched
                    if (dog.getTrainingStatus().equalsIgnoreCase("In Service")) { // if training status is set to "in service"
                        inServiceAnimals += 1; // the number of in service animals increments by 1
                    }
                }
                for (Monkey monkey: monkeyList) { // next, the monkey list is searched
                    if (monkey.getTrainingStatus().equalsIgnoreCase("In Service")) { // if training status is set to "in service"
                        inServiceAnimals += 1; // the number of in service animals increments by 1
                    }
                }

                // this loop searches both lists to find number of animals in service that are available
                for (Dog dog: dogList) { // first, the dog list is searched
                    if (dog.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                            && !dog.getReserved()) // and reserved status is false
                    {
                        availableAnimals += 1; // the number of in service animals increments by 1
                    }
                }
                for (Monkey monkey: monkeyList) { // next, the monkey list is searched
                    if (monkey.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                            && !monkey.getReserved()) // and reserved status is false
                    {
                        availableAnimals += 1; // the number of in service animals increments by 1
                    }
                }

                // this block of text provides feedback to the user on the organization's numbers
                System.out.println("\nTracking: ");
                System.out.println(totalAnimals + " Total Animal(s)"); // prints total animals
                System.out.println(inServiceAnimals + " In-Service"); // prints number of animals in service
                System.out.println(availableAnimals + " Available"); // prints number of animals available
                System.out.println("\nPrinting list of All Available Animals..."); // feedback for user convenience

                // this loop prints the compiled list of animals being tracked that are available for use
                while (availableAnimals > 0) { // counts down the total of available animals
                    int counter = 1; // the tracks the chronology of animal information being printed
                    for (Dog dog : dogList) { // first, the dog list is searched
                        if (dog.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                                && !dog.getReserved()) // and reserved status is false
                        {
                            System.out.println("\nAnimal Number " + counter); // prints animal number
                            System.out.println("\n\tAnimal Type: Dog\n"); // prints animal type
                            System.out.println("\tName: " + dog.getName()); // prints animal name
                            System.out.println("\tStatus: " + dog.getTrainingStatus()); // prints animal training status
                            System.out.println("\tAcquisition Country: " + dog.getAcquisitionLocation()); // prints animal acquisition location
                            System.out.println("\tReserved: " + dog.getReserved()); // prints animal reservation status
                            availableAnimals += -1; // decrements number of available animals
                            counter += 1; // increments the animal number
                        }
                    }
                    for (Monkey monkey : monkeyList) { // next, the monkey list is searched
                        if (monkey.getTrainingStatus().equalsIgnoreCase("In Service") // if training status is set to "in service"
                                && !monkey.getReserved()) // and reserved status is false
                        {
                            System.out.println("\nAnimal Number " + counter); // prints animal number continued from previous for loop
                            System.out.println("\n\tAnimal Type: Monkey\n"); // prints animal type
                            System.out.println("\tName: " + monkey.getName()); // prints animal name
                            System.out.println("\tStatus: " + monkey.getTrainingStatus()); // prints animal training status
                            System.out.println("\tAcquisition Country: " + monkey.getAcquisitionLocation()); // prints animal acquisition location
                            System.out.println("\tReserved: " + monkey.getReserved()); // prints animal reservation status
                            availableAnimals += -1; // decrements number of available animals
                            counter += 1; // increments the animal number
                        }
                    }
                }

                break;
            default:
                System.out.println("Default Case Error in Print List Method Call");
                break;
        }
    }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // End of Code for Driver Class
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

