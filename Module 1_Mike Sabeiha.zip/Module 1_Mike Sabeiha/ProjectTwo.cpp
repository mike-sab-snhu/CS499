//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Mike Sabeiha
// Version     : 1.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Module 7 | Project Two
//============================================================================

#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <time.h>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch); //data type converstion function
void displayMenu(); //prints menu to save some space in main loop
bool validChoice(string ch); //validation check on menu options
bool validCourse(string cr); //validation check on search input

//vector to hold sorted list
vector<string> sortedList;

// object structure to hold course information
struct Course {
    string courseId; // unique identifier
    string courseName;
    string preReqOne;
    string preReqTwo;
};

//============================================================================
// Linked-List class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a linked-list.
 */
class LinkedList {

private:
    //Internal structure for list entries, housekeeping variables
    struct Node {
        Course course;
        Node* next;
        Node* prev;

        // default constructor
        Node() {
            next = nullptr;
            prev = nullptr;
        }

        // initialize with a course
        Node(Course aCourse) {
            course = aCourse;
            next = nullptr;
            prev = nullptr;
        }
    };

    Node* head;
    Node* tail;
    int size = 0; //counts size of linkedlist
    int rsize = 0; //counts number of courses read
    int ldErrCount = 0; //counts errors when loading list

public:
    LinkedList(); //constructor
    virtual ~LinkedList(); //destructor
    void Append(Course course); //adds courses to linked list
    void SortList(); //sorts courses alphanumerically
    void PrintList(); //prints courses alphanumerically
    Course Search(string courseId); //search function
    int Size(); //size of linkedlist
    int rSize(); //size of items read during loading
    int eSize(); //size of errors encountered during loading
};

/**
 * Default constructor
 */
LinkedList::LinkedList() {
    //this initializes a head and tail sentinel for the linked list

    //head
    //creating a new course and loading it with head sentinel values
    Course* hcourse = new Course;
    hcourse->courseId = "AAAA000";
    hcourse->courseName = "HEAD SENTINEL";
    
    //setting the head node's course object to hcourse which holds head sentinel values
    head = new Node;
    head->course = *hcourse;

    //tail
    //creating a new course and loading it with tail sentinel values
    Course* tcourse = new Course;
    tcourse->courseId = "ZZZZ999";
    tcourse->courseName = "TAIL SENTINEL";

    //setting the tail node's course object to tcourse which holds tail sentinel values
    tail = new Node;
    tail->course = *tcourse;

    //now pointers are set
    head->prev = nullptr; //setting head node's previous value to nullptr
    head->next = tail; //setting head node's next value to tail
    tail->prev = head; //setting tail node's previous value to head
    tail->next = nullptr; //setting tail node's next value to nullptr
}

/**
 * Destructor
 */
LinkedList::~LinkedList() {
    // start at the head
    Node* current = head;
    Node* temp;

    // loop over each node, detach from list then delete
    while (current != nullptr) {
        temp = current; // hang on to current node
        current = current->next; // make current the next node
        delete temp; // delete the orphan node
    }
}

/**
 * Append a new course to the end of the list
 */
void LinkedList::Append(Course course) {
    rsize++; //increment count of items read

    Node* newNode = new Node; //create new node

    //check if list is empty with only sentinel nodes in place
    if ((head->next == tail) && (tail->prev == head)) {
        
        //resetting pointers
        head->next = newNode; //head node next pointer goes to new node
        tail->prev = newNode; //tail node prev pointer goes to new node
        newNode->prev = head; //new node prev pointer goes to head
        newNode->next = tail; //new node next pointer goes to tail
        
        //assigning input course as new node's course object
        newNode->course = course;
        
        size++; //increment list size
    }
    else { //if the list has more than just sentinel values (ie not empty)
        if ((head->next != tail) && (tail->prev != head)) {
            
            //resetting pointers
            newNode->prev = tail->prev; //new node's previous is tail's old previous
            newNode->next = tail; //new node's next is tail
            tail->prev->next = newNode; //tail's old previous has next pointer set to new node
            tail->prev = newNode; //tail's previous pointer is updated to newNode

            //assigning input course as new node's course object
            newNode->course = course;

            size++; //increment list size
        }
        else {
            std::cout << "Error loading " << course.courseId << endl; //print error message
            ldErrCount++; //increment load error count
        }
    }
}


/**
 * Sort all courses into new list
 */
void LinkedList::SortList() {
    //initializing variables and containers
    
    //variables to hold courses for comparison
    string front;
    string spot;
    string back;
    string hold;

    //variables to hold position of course ID in sortedList
    unsigned int frontLoc;
    unsigned int spotLoc;
    unsigned int backLoc;
    
    //initializing resources for the loop
    Node* temp = head->next; //zero node
    int swapCount = 0; //tracks swaps made
    bool loopBreak = false; //breaks while loop

    //STAGE 1: Add unique courses from courseList to sortedList

    sortedList.push_back(temp->course.courseId); //adding the first node to sortedList
    
    while (temp != tail) { //while the node being assessed from LinkedList is not the tail
        spot = temp->course.courseId; //grabbing the courseId of the first node
        for (int i = 0; i < sortedList.size(); i++) { //looping through sortedList
            if (spot == sortedList[i]) { //if there is a duplicate
                loopBreak = true; //break loop toggle gets triggered
                break; //for loop is exited
            }
            else { //if not duplicate...
                continue; //...keep looking for an empty space
            }
        }

        if (loopBreak == true) { //if the was a duplicate
            loopBreak = false; //reset the duplicate trigger
            temp = temp->next; //move onto the next node from courseList
        }
        else { //if there was not a duplicate
            sortedList.push_back(spot); //add the node to sortedList
            temp = temp->next; //scroll to the next node from courseList
        }
    }

    //STAGE 2: Sort values in sortedList

    loopBreak = false; //resetting loopbreak for the next stage
    while (loopBreak == false) { //while loop entered

        for (int i = 0; i < sortedList.size(); i++) { //scroll sortedList
            
            if (i == 0) { //if first item is in frame
                spot = sortedList[i]; //the spot item is sortedList at frame
                spotLoc = i; //spot location is frame

                back = sortedList[i + 1]; //the back item is sortedList at frame + 1
                backLoc = i + 1; //the back item location is frame + 1

                if (spot > back) { //if spot is greater than back, swap their positions
                    hold = spot;
                    sortedList[spotLoc] = back;
                    sortedList[backLoc] = hold;

                    swapCount++; //increment swap count
                }
            }
            else if ((i + 1) == sortedList.size()) { //if last item is in frame
                spot = sortedList[i]; //spot is frame
                spotLoc = i;

                front = sortedList[i - 1]; //assess front item against spot
                frontLoc = i - 1;

                if (spot < front) { //if spot is less than front item, swap their positions
                    hold = spot;
                    sortedList[spotLoc] = front;
                    sortedList[frontLoc] = hold;

                    swapCount++; //increment swap count
                }
            }
            else { //if item is somewhere between the first and last item in sortedList
                front = sortedList[i - 1]; //front item
                frontLoc = i - 1;

                spot = sortedList[i]; //spot item
                spotLoc = i;

                back = sortedList[i + 1]; //back item
                backLoc = i + 1;

                if (spot > back) { //if spot is larger than back, swap them
                    
                    hold = spot;
                    sortedList[spotLoc] = back;
                    sortedList[backLoc] = hold;

                    swapCount++; //increment swap count
                }
                else if (spot < front) { //if spot is smaller than front, swap them

                    hold = spot;
                    sortedList[spotLoc] = front;
                    sortedList[frontLoc] = hold;

                    swapCount++; //increment swap count
                }
            }
        }

        if (swapCount == 0) { //if no swaps were made in this iteration of the for loop
            loopBreak = true; //break the while loop
        }
        else { //if at least one swap was made, there is still sorting to be done
            swapCount = 0; //reset swap count to zero and repeat for loop
        }
    }
}

/**
 * Search for the specified course
 */
Course LinkedList::Search(string CourseId) {

    Course course;
    Node* node;

    node = head->next; //begin search at head node + 1
    while (node != tail) { //as long as we aren't looking at the tail node
        if (node->course.courseId == CourseId) { //see if there is a match
            course = node->course; //if matched, grab the course object from the node in frame
            return course; //return the course object for further processing
        }
        else { //if no match
            node = node->next; //move on to the next node
        }
    }

    return course; //default empty course returned

}

/**
 * Simple output of all bids in the list
 */
void LinkedList::PrintList() {

    Course frame;

    for (int i = 0; i < sortedList.size(); i++) { //scroll sortedList
            
        frame = Search(sortedList.at(i)); //use search to grab course object based on courseId
        std::cout << "Course ID: " << frame.courseId << endl; //print basic info
        std::cout << "Course Name: " << frame.courseName << endl;

        if (frame.preReqOne != "") { //don't print if this info is blank
            std::cout << "Pre-Req One: " << frame.preReqOne << endl;
        }
        if (frame.preReqTwo != "") { //don't print if this info is blank
            std::cout << "Pre-Req Two: " << frame.preReqTwo << endl;
        }

        std::cout << endl;

    }
}



/**
 * Returns list size
 */
int LinkedList::Size() {
    return size;
}

/**
 * Returns read items size
 */
int LinkedList::rSize() {
    return rsize;
}

/**
 * Returns error size
 */
int LinkedList::eSize() {
    return ldErrCount;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the course information
 *
 * @param course struct containing the course info
 */
void displayCourse(Course course) {
    std::cout << "Course ID: " << course.courseId << endl;
    std::cout << "Course Name: " << course.courseName << endl;
    std::cout << "Pre-Req One: " << course.preReqOne << endl;
    std::cout << "Pre-Req Two: " << course.preReqTwo << endl;
    return;
}

/**
 * Load a CSV file containing courses into a LinkedList containing all the courses read
 */
void loadCourses(string csvPath, LinkedList* list) {

    ifstream file; //variable to hold file for import
    file.open(csvPath, ios::in); //opening file at location csvPath

    string line; //variable to hold each line pulled from file
    vector<string> lines; //vector to hold all lines pulled from file

    while (getline(file, line)) { //while the getlines method is pulling information as lines from file
        lines.push_back(line); //add those lines to the vector for storing lines
    }
    file.close(); //close the file

    //This next block pulls lines of data then breaks them down into data points

    for (int i = 0; i < lines.size(); i++) { //scroll the vector holding lines
        vector<string> temp; //working variable to store data as we break down lines into data points
        int comma; //variable to hold location of commas found in lines
        string frame = lines.at(i); //variable to hold the string derived from each line
        string data; //variable to hold the data point to be transferred to course object
    
        comma = find(frame.begin(), frame.end(), ',') - frame.begin(); //find the first comma in string
        data = frame.substr(0, comma); //derive a substring from start to that comma location
        temp.push_back(data); //add that to vector storing data points
        frame = frame.erase(0, comma + 1); //shorten the string to remove data already isolated
        
        comma = find(frame.begin(), frame.end(), ',') - frame.begin(); //second iteration
        data = frame.substr(0, comma);
        temp.push_back(data);
        frame = frame.erase(0, comma + 1);
        
        comma = find(frame.begin(), frame.end(), ',') - frame.begin(); //third iteration
        data = frame.substr(0, comma);
        temp.push_back(data);
        frame = frame.erase(0, comma + 1);

        comma = find(frame.begin(), frame.end(), ',') - frame.begin(); //fourth iteration
        data = frame.substr(0, comma);
        temp.push_back(data);
        frame = frame.erase(0, comma + 1);

        //cout << temp.at(0) << " | " << temp.at(1) << " | " << temp.at(2) << " | " << temp.at(3) << endl;

        Course course; //create new course object
        course.courseId = temp.at(0); //transfer derived data point 1 to Course ID
        course.courseName = temp.at(1); //transfer derived data point 2 to Course Name
        course.preReqOne = temp.at(2); //transfer derived data point 3 to Pre-Requisite One
        course.preReqTwo = temp.at(3); //transfer derived data point 4 to Pre-Requisite Two

        //cout << course.courseId << " | " << course.courseName << " | " << course.preReqOne << " | " << course.preReqTwo << endl;
    
        list->Append(course); //add the new course to courseList
    
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

//displays menu on command
void displayMenu() {
    std::cout << "Welcome to the Course Planner." << endl;
    std::cout << endl;

    std::cout << "  1. Load Courses" << endl;
    std::cout << "  2. Print List of Courses" << endl;
    std::cout << "  3. Find Course Details" << endl;
    std::cout << "  9. Exit" << endl;
    std::cout << "What would you like to do? ";
}

//checks to see if user input for menu options is valid
bool validChoice(string ch) {
    string sinput = ch; //set working variable to userInput string
    int xinput; //will hold the integer value of input

    if (sinput.length() != 1) { //if the string is not equal to length 1
        return false; //return false so the loop repeats
    }

    //if the userInput string is equal to length 1
    xinput = stoi(sinput);

    //run conditional checks
    if ((xinput != 1) && (xinput != 2) && (xinput != 3) && (xinput != 9)) { //doesnt match menu options
        return false;
    }
    if ((xinput == 1) || (xinput == 2) || (xinput == 3) || (xinput == 9)) { //does match menu options
        return true;
    }
    else { //errors
        return false;
    }
}

//checks to see if user input for single course selection is valid
bool validCourse(string cr) {
    string input = cr;

    if (input.length() != 7) { //check length is equal to 7
        return false;
    }
    return true;
}

/**
 * The one and only main() method
 *
 * @param arg[1] path to CSV file to load from (optional)
 * @param arg[2] the course Id to use when searching the list (optional)
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, courseKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        courseKey = "MATH201";
        break;
    case 3:
        csvPath = argv[1];
        courseKey = argv[2];
        break;
    default:
        csvPath = "CS 300 ABCU_Advising_Program_Input.csv";
        courseKey = "MATH201";
    }

    //initializing list and variables
    LinkedList courseList; //list to hold data
    Course course; //working variable to hold course info
    string userInput; //working variable to hold user input for menu choice
    int choice; //working variable to hold user input for menu options
    bool vChoice = false; //working variable to hold validity of user input for menu options
    bool vCourse = false; //working variable to hold validity of user input for select course
    int mLoopCount = 0; //counts the number of times the menu has been looped

    //displaying menu for the first time before entering validation loops
    displayMenu();
    std::cin >> userInput; //receiving user input
    vChoice = validChoice(userInput); //validation checking user input

    //if choice is invalid this loop is entered
    while (vChoice == false) { //the loop is repeated until the user enters valid input

        //user is informed that their input was invalid
        cout << userInput << " is not a valid option." << endl;
        cout << endl;

        displayMenu(); //the menu is printed again
        std::cin >> userInput; //the new user input is saved to choice
        vChoice = validChoice(userInput); //the input is validated again
    }

    //convert userInput from string to integer
    choice = stoi(userInput);

    while (choice != 9) {
        if (mLoopCount > 0) {// if the menu has been looped at least once, display menu again
            //displaying menu for the first time before entering validation loops
            displayMenu();
            std::cin >> userInput; //receiving user input
            vChoice = validChoice(userInput); //validation checking user input

            //if choice is invalid this loop is entered
            while (vChoice == false) { //the loop is repeated until the user enters valid input

                //user is informed that their input was invalid
                cout << userInput << " is not a valid option." << endl;
                cout << endl;

                displayMenu(); //the menu is printed again
                std::cin >> userInput; //the new user input is saved to choice
                vChoice = validChoice(userInput); //the input is validated again
            }

            //convert userInput from string to integer
            choice = stoi(userInput);

        } //if the menu has not looped at least once, menu is not printed again

        switch (choice) {
        case 1: //load courses from csv file
            cout << "Loading courses..." << endl; //informing user of action started

            loadCourses(csvPath, &courseList); //leading courses from file provided to list created

            cout << endl;
            cout << courseList.rSize() << " courses read" << endl; //informing user of items read
            cout << courseList.Size() << " courses added" << endl; //informing user of total items added
            cout << courseList.eSize() << " errors found" << endl; //informing user of items read but not entered
            cout << endl;

            courseList.SortList();

            mLoopCount++; //iterating loop count so the menu will print next time
            break; //exiting switch

        case 2: //print courses in alphanumeric order
            cout << endl;
            cout << "Here is a sample schedule:" << endl; //informing user of action taken
            cout << endl;
            
            courseList.PrintList(); //printing course list
            cout << endl;

            mLoopCount++; //iterating loop count so the menu will print next time
            break; //exiting switch

        case 3: //print single course details
            cout << "What course do you want to know about? ('exit' to leave) "; //requesting user input
            std::cin >> courseKey; //user input to variable
            if (courseKey == "exit") { //if user wants to exit
                mLoopCount++; //iterate loop count to print menu next time
                break; //exiting switch
            }
            else { //the user does not want to exit
                vCourse = validCourse(courseKey); //validate input for course selection
            }

            while (vCourse == false) { //while user input is invalid
                cout << "Your selection is invalid." << endl; //inform user of invalid input
                cout << endl;

                cout << "What course do you want to know about? ('exit' to leave) "; //let them try again
                std::cin >> courseKey; //user input to variable, again
                if (courseKey == "exit") { //if user wants to exit, again
                    mLoopCount++; //iterating loop count to print menu next time, again
                    break; //exiting switch, again
                }
                else { //the user doesn not want to exit, again
                    vCourse = validCourse(courseKey); //validate user input for course selection, again
                }
            }

            if (courseKey != "exit") {
                course = courseList.Search(courseKey); //searching course list and setting results to variable

                if (!course.courseId.empty()) { //if the reults aren't blank
                    cout << endl;
                    displayCourse(course); //print course details
                }
                else { //if the results are blank (the course was not found)
                    cout << "Course Id " << courseKey << " not found." << endl; //inform the user
                }
            }
            
            cout << endl;
            mLoopCount++; //iterating loop count to print menu next time, again
            break; //exiting switch, again

        }
    }

    cout << "Thank you for using the course planner!" << endl; //goodbye prompt

    return 0; //exit with 0
}
