// Mike Sabeiha
// SNHU: CS 499
// Captstone
// Module 5: Improvements
// 2026 04 12

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

int main() {
    std::string filename = "data.csv";
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Error: Could not open the file!" << std::endl;
        return 1;
    }

    // A vector of vectors to store the full CSV (rows and columns)
    std::vector<std::vector<std::string>> data;
    std::string line;

    // Read the file line by line
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        std::vector<std::string> row;

        // Extract each value separated by a comma
        while (std::getline(ss, value, ',')) {
            row.push_back(value);
        }

        // Add the completed row to our main data structure
        data.push_back(row);
    }

    file.close();

    // Example of accessing the data: printing it to the console
    for (const auto& row : data) {
        for (const auto& field : row) {
            std::cout << field << " | ";
        }
        std::cout << std::endl;
    }

    return 0;
}