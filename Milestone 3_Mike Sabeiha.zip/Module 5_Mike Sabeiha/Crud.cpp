// Mike Sabeiha
// SNHU: CS 499
// Captstone
// Module 5: Improvements
// 2026 04 12

#include <iostream>
#include <vector>
#include <string>
#include <algorithm> // For std::remove_if
#include <limits>

struct Animal {
    std::string name;
    std::string species;
    int age;
};

void clearBuffer() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

int main() {
    std::vector<Animal> database;
    int choice;

    do {
        std::cout << "\n--- Animal Rescue CRUD ---\n"
            << "1. Create (Add Animal)\n"
            << "2. Read (View All)\n"
            << "3. Update (Edit Animal)\n"
            << "4. Delete (Remove Animal)\n"
            << "5. Exit\n"
            << "Choice: ";

        if (!(std::cin >> choice)) { clearBuffer(); continue; }
        clearBuffer();

        switch (choice) {
        case 1: { // CREATE
            Animal a;
            std::cout << "Name: "; std::getline(std::cin, a.name);
            std::cout << "Species: "; std::getline(std::cin, a.species);
            std::cout << "Age: "; std::cin >> a.age;
            database.push_back(a);
            std::cout << "Record saved.\n";
            break;
        }
        case 2: { // READ
            if (database.empty()) { std::cout << "Database is empty.\n"; break; }
            for (const auto& a : database) {
                std::cout << "[" << a.name << "] " << a.species << ", Age: " << a.age << "\n";
            }
            break;
        }
        case 3: { // UPDATE
            std::string target;
            std::cout << "Enter name of animal to update: ";
            std::getline(std::cin, target);
            bool found = false;
            for (auto& a : database) {
                if (a.name == target) {
                    std::cout << "New Species: "; std::getline(std::cin, a.species);
                    std::cout << "New Age: "; std::cin >> a.age;
                    std::cout << "Record updated.\n";
                    found = true;
                    break;
                }
            }
            if (!found) std::cout << "Animal not found.\n";
            break;
        }
        case 4: { // DELETE
            std::string target;
            std::cout << "Enter name of animal to remove: ";
            std::getline(std::cin, target);

            auto it = std::remove_if(database.begin(), database.end(),
                [&](const Animal& a) { return a.name == target; });

            if (it != database.end()) {
                database.erase(it, database.end());
                std::cout << "Record deleted.\n";
            }
            else {
                std::cout << "Animal not found.\n";
            }
            break;
        }
        }
    } while (choice != 5);

    return 0;
}