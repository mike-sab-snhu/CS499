// Mike Sabeiha
// SNHU: CS 499
// Captstone
// Module 5: Improvements
// 2026 04 12

#include <iostream>
#include <vector>
#include <string>
#include <limits> // Required for clearing the input buffer

struct Animal {
    std::string name;
    std::string species;
    std::string breed;
    int age;
};

// Helper function to clear leftover characters in the input buffer
void clearBuffer() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

int main() {
    std::vector<Animal> database;
    int choice;

    do {
        // Dialogue Menu
        std::cout << "\n--- Animal Database ---\n";
        std::cout << "1. Add a New Record\n";
        std::cout << "2. View All Records\n";
        std::cout << "3. Exit\n";
        std::cout << "Enter your choice: ";

        // Basic input validation
        if (!(std::cin >> choice)) {
            std::cout << "Invalid input. Please enter a number.\n";
            clearBuffer();
            continue;
        }

        switch (choice) {
        case 1: {
            Animal newAnimal;
            clearBuffer(); // Clear buffer before using getline

            std::cout << "Enter animal name: ";
            std::getline(std::cin, newAnimal.name);

            std::cout << "Enter species (e.g., Dog, Cat): ";
            std::getline(std::cin, newAnimal.species);

            std::cout << "Enter breed: ";
            std::getline(std::cin, newAnimal.breed);

            std::cout << "Enter age: ";
            while (!(std::cin >> newAnimal.age)) {
                std::cout << "Please enter a valid number for age: ";
                clearBuffer();
            }

            database.push_back(newAnimal); // Store record in vector
            std::cout << "Record added successfully!\n";
            break;
        }
        case 2:
            if (database.empty()) {
                std::cout << "The database is currently empty.\n";
            }
            else {
                std::cout << "\n--- Current Records ---\n";
                for (const auto& animal : database) {
                    std::cout << "Name: " << animal.name
                        << " | Species: " << animal.species
                        << " | Breed: " << animal.breed
                        << " | Age: " << animal.age << "\n";
                }
            }
            break;
        case 3:
            std::cout << "Exiting program. Goodbye!\n";
            break;
        default:
            std::cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 3);

    return 0;
}