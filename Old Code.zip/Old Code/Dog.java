// Subclss builds off Rescue Animals
public class Dog extends RescueAnimal {

    // Instance variable
    private String breed;

    // Constructor with detailed inputs that sets object attributes according to input on each instance
    public Dog(String name, String breed, String gender, String age,
               String weight, String acquisitionDate, String acquisitionCountry,
               String trainingStatus, boolean reserved, String inServiceCountry) {

        setName(name); // dog name
        setBreed(breed); // dog breed
        setGender(gender); // dog gender
        setAge(age); // dog age
        setWeight(weight); // dog weight
        setAcquisitionDate(acquisitionDate); // dog acquisition date
        setAcquisitionLocation(acquisitionCountry); // dog acquisition country
        setTrainingStatus(trainingStatus); // dog training status
        setReserved(reserved); // dog reserved status
        setInServiceCountry(inServiceCountry); // dog service country

    }

    // Accessor Method to call breed
    public String getBreed() {
        return breed;
    }

    // Mutator Method to update breed
    public void setBreed(String dogBreed) {
        breed = dogBreed;
    }

}
