// Superclass to construct animal objects
import java.lang.String;

public class RescueAnimal { // class that holds framework for building objects to store and manipulate animal data

    // Instance variables
    private String name; // animal name as private string
    private String animalType; // animal type as private string
    private String gender; // animal gender as private string
    private String age; // animal age as private string
    private String weight; // animal weight as private string
    private String acquisitionDate; // animal acquisition date as private string
    private String acquisitionCountry; // animal acquisition country as private string
	private String trainingStatus; // animal training status as private string
    private boolean reserved; // animal reserved status as private string
	private String inServiceCountry; // animal service country as private string


    // Constructor to build animal objects (generic)
    public RescueAnimal() {
    }

	// getter to caller animal name
	public String getName() {
		return name;
	}

	// setter to update animal name
	public void setName(String name) {
		this.name = name;
	}

	// getter to call animal type
	public String getAnimalType() {
		return animalType;
	}

	// setter to update animal type
	public void setAnimalType(String animalType) {
		this.animalType = animalType;
	}

	// getter to call animal gender
	public String getGender() {
		return gender;
	}

	// setter to update animal gender
	public void setGender(String gender) {
		this.gender = gender;
	}

	// getter to call animal age
	public String getAge() {
		return age;
	}

	// setter to update animal age
	public void setAge(String age) {
		this.age = age;
	}

	// getter to call animal weight
	public String getWeight() {
		return weight;
	}

	// setter to update animal weight
	public void setWeight(String weight) {
		this.weight = weight;
	}

	// getter to call animal acquisition date
	public String getAcquisitionDate() {
		return acquisitionDate;
	}

	// setter to update animal acquisition date
	public void setAcquisitionDate(String acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}

	// getter to call animal acquisition location
	public String getAcquisitionLocation() {
		return acquisitionCountry;
	}

	// setter to update animal acquisition location
	public void setAcquisitionLocation(String acquisitionCountry) {
		this.acquisitionCountry = acquisitionCountry;
	}

	// getter to call animal reserved status
	public boolean getReserved() {
		return reserved;
	}

	// setter to update animal reserved status
	public void setReserved(boolean reserved) {
		this.reserved = reserved;
	}

	// getter to call animal service location
	public String getInServiceLocation() {
		return inServiceCountry;
	}

	// setter to update animal service location
	public void setInServiceCountry(String inServiceCountry) {
		this.inServiceCountry = inServiceCountry;
	}

	// getter to call animal training status
	public String getTrainingStatus() {
		return trainingStatus;
	}

	// setter to update animal training status
	public void setTrainingStatus(String trainingStatus) {
		this.trainingStatus = trainingStatus;
	}
}
