// Subclass builds off Rescue Animals
public class Monkey extends RescueAnimal {

    // Instance variable
    private String species;
    private String height;
    private String bodyLength;
    private String tailLength;

    // Constructor with detailed inputs that sets object attributes according to input on each instance
    public Monkey(String name, String species, String gender, String age,
                  String height, String bodyLength, String tailLength,
                  String weight, String acquisitionDate, String acquisitionCountry,
                  String trainingStatus, boolean reserved, String inServiceCountry) {

        setName(name); // monkey name
        setSpecies(species); // monkey species
        setGender(gender); // monkey gender
        setAge(age); // monkey age
        setHeight(height); // monkey height
        setBodyLength(bodyLength); // monkey body length
        setTailLength(tailLength); // monkey tail length
        setWeight(weight); // monkey weight
        setAcquisitionDate(acquisitionDate); // monkey acquisition date
        setAcquisitionLocation(acquisitionCountry); // monkey acquisition country
        setTrainingStatus(trainingStatus); // monkey training status
        setReserved(reserved); // monkey reserved status
        setInServiceCountry(inServiceCountry); // monkey service country

    }

    // Accessor Method for Species
    public String getSpecies() {
        return species;
    }

    // Mutator Method for Species
    public void setSpecies(String inpSpecies) {
        species = inpSpecies;
    }

    // Accessor Method for height
    public String getHeight() {
        return height;
    }

    // Mutator Method for height
    public void setHeight(String inpHeight) {
        height = inpHeight;
    }

    // Accessor Method for body length
    public String getBodyLength() {
        return bodyLength;
    }

    // Mutator Method for body length
    public void setBodyLength(String inpBodyLength) {
        bodyLength = inpBodyLength;
    }

    // Accessor Method for tail length
    public String getTailLength() {
        return tailLength;
    }

    // Mutator Method for tail length
    public void setTailLength(String inpTailLength) {
        tailLength = inpTailLength;
    }

}
